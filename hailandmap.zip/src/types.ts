/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface UniqueAddress {
  id: string;
  latitude: number;
  longitude: number;
  createdAt: string;
  status: 'En attente de vérification livreur' | 'Validé par le livreur' | 'Refusé';
  name?: string;
  notes?: string;
  buildingId?: string | number;
  geometry?: any; // Stocke la géométrie GeoJSON (Polygon/MultiPolygon)
  area?: number; // Surface estimée en m²
}

export interface RouteInfo {
  distance: number; // en mètres
  duration: number; // en secondes
  coordinates: [number, number][];
}
