/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState } from 'react';
import mapboxgl from 'mapbox-gl';
import { 
  MapPin, 
  Navigation, 
  Search, 
  Compass, 
  Layers, 
  Check, 
  Code, 
  Clock, 
  X, 
  ChevronRight, 
  Plus, 
  CheckCircle, 
  Truck, 
  Map as MapIcon, 
  RefreshCw,
  Info,
  Sparkles,
  Undo2,
  ChevronUp,
  ChevronDown,
  AlertTriangle,
  Menu,
  ChevronLeft
} from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';
import { UniqueAddress, RouteInfo } from './types';
import * as turf from '@turf/turf';

// Valeur par défaut de repli pour le jeton Mapbox
const DEFAULT_MAPBOX_TOKEN = 'pk.eyJ1IjoiaGFpbGFuZCIsImEiOiJjbXFiZGduOXkwZGF6MnNxd3JubWphNTR0In0.DXOWxUQGD-iPWLSehiZ4Ow';
const CUSTOM_STYLE_URL = 'mapbox://styles/hailand/cmqbiiccq000b01qr7ckjeut1';

// Liste initiale d'adresses d'exemples à Conakry, Guinée
const INITIAL_ADDRESSES: UniqueAddress[] = [
  {
    id: 'HLM-CON-4509',
    latitude: 9.5092,
    longitude: -13.7122,
    createdAt: '2026-06-12T10:30:15Z',
    status: 'En attente de vérification livreur',
    name: 'Maison Traoré (Kaloum)',
    notes: 'Près du Palais Présidentiel, portail blanc',
    buildingId: 'building-1092'
  },
  {
    id: 'HLM-CON-8720',
    latitude: 9.5415,
    longitude: -13.6705,
    createdAt: '2026-06-11T14:15:22Z',
    status: 'En attente de vérification livreur',
    name: 'Palais du Peuple (Dixinn)',
    notes: 'Juste en face de la grande esplanade',
    buildingId: 'building-2038'
  },
  {
    id: 'HLM-CON-1102',
    latitude: 9.5885,
    longitude: -13.6210,
    createdAt: '2026-06-10T08:05:00Z',
    status: 'En attente de vérification livreur',
    name: 'Résidence Camara (Ratoma)',
    notes: 'À côté de la Pharmacie Ratoma, barrière noire',
    buildingId: 'building-5014'
  }
];

// Point par défaut à Conakry pour la simulation de départ
const DEFAULT_SIMULATED_GPS = {
  latitude: 9.5180, // Proche Kaloum
  longitude: -13.7050
};

/**
 * Calcule la distance entre deux coordonnées géographiques en mètres (formule de Haversine).
 */
function calculateDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371000; // Rayon de la Terre en mètres
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = 
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * 
    Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

/**
 * Calcule l'aire d'un polygone de coordonnées en mètres carrés (m²) de façon plane locale.
 */
function calculatePolygonArea(coordinates: [number, number][][]): number {
  if (!coordinates || coordinates.length === 0 || coordinates[0].length < 3) return 0;
  const ring = coordinates[0];
  const n = ring.length;
  if (n < 3) return 0;
  
  // Barycentre pour la projection locale plane
  let sumLng = 0;
  let sumLat = 0;
  ring.forEach(pt => {
    sumLng += pt[0];
    sumLat += pt[1];
  });
  const refLng = sumLng / n;
  const refLat = sumLat / n;
  
  const radLat = (refLat * Math.PI) / 180;
  const kx = 111320 * Math.cos(radLat); // mètres par degré de long
  const ky = 110540; // mètres par degré de lat
  
  // Formule de Shoelace
  let area = 0;
  for (let i = 0; i < n; i++) {
    const pt1 = ring[i];
    const pt2 = ring[(i + 1) % n];
    
    const x1 = (pt1[0] - refLng) * kx;
    const y1 = (pt1[1] - refLat) * ky;
    const x2 = (pt2[0] - refLng) * kx;
    const y2 = (pt2[1] - refLat) * ky;
    
    area += (x1 * y2) - (x2 * y1);
  }
  
  return Math.round(Math.abs(area / 2));
}

/**
 * Génère un polygone carré de dimension donnée autour de coordonnées géographiques (pour simulation de zone).
 */
function generateSquarePolygon(lng: number, lat: number, halfSideMeters: number = 8): { type: "Polygon"; coordinates: [number, number][][] } {
  const radLat = (lat * Math.PI) / 180;
  const deltaLat = halfSideMeters / 110540;
  const deltaLng = halfSideMeters / (111320 * Math.cos(radLat));
  
  const p1: [number, number] = [lng - deltaLng, lat - deltaLat];
  const p2: [number, number] = [lng + deltaLng, lat - deltaLat];
  const p3: [number, number] = [lng + deltaLng, lat + deltaLat];
  const p4: [number, number] = [lng - deltaLng, lat + deltaLat];
  const p5: [number, number] = [lng - deltaLng, lat - deltaLat]; // Refermer
  
  return {
    type: 'Polygon',
    coordinates: [[p1, p2, p3, p4, p5]]
  };
}

/**
 * Récupère dynamiquement tous les calques polygonaux de la carte actifs
 * pour s'assurer que chaque polygone (bâtiment, parcelle, etc.) soit cliquable / sélectionnable.
 */
function getSelectableLayers(map: mapboxgl.Map): string[] {
  try {
    const existingLayers = map.getStyle()?.layers || [];
    return existingLayers
      .filter(l => l.type === 'fill' || l.type === 'fill-extrusion')
      .map(l => l.id)
      .filter(id => 
        id !== 'selected-building-fill' &&
        id !== 'selected-building-outline' &&
        id !== 'selected-building-3d' &&
        id !== 'hovered-building-fill' &&
        id !== 'hovered-building-outline' &&
        id !== 'hovered-building-3d' &&
        id !== 'draw-fill' &&
        id !== 'draw-line' &&
        id !== 'draw-points'
      );
  } catch (err) {
    return [];
  }
}

/**
 * Simplification de polygone via l'algorithme classique de Douglas-Peucker
 * Réduit le bruit de crénelage de pixels pour donner un rendu géométrique propre (droites de toitures).
 */
function simplifyPolygon(points: [number, number][], tolerance: number): [number, number][] {
  if (points.length <= 4) return points;
  
  const getSqSegDist = (p: [number, number], p1: [number, number], p2: [number, number]) => {
    let x = p1[0], y = p1[1], dx = p2[0] - x, dy = p2[1] - y;
    if (dx !== 0 || dy !== 0) {
      const t = ((p[0] - x) * dx + (p[1] - y) * dy) / (dx * dx + dy * dy);
      if (t > 1) {
        x = p2[0]; y = p2[1];
      } else if (t > 0) {
        x += dx * t; y += dy * t;
      }
    }
    dx = p[0] - x; dy = p[1] - y;
    return dx * dx + dy * dy;
  };

  const simplifyDPStep = (pts: [number, number][], first: number, last: number, sqTolerance: number, simplified: [number, number][]) => {
    let maxSqDist = sqTolerance, index = -1;
    for (let i = first + 1; i < last; i++) {
      const sqDist = getSqSegDist(pts[i], pts[first], pts[last]);
      if (sqDist > maxSqDist) {
        index = i;
        maxSqDist = sqDist;
      }
    }
    if (index !== -1) {
      if (index - first > 1) simplifyDPStep(pts, first, index, sqTolerance, simplified);
      simplified.push(pts[index]);
      if (last - index > 1) simplifyDPStep(pts, index, last, sqTolerance, simplified);
    }
  };

  const simplified: [number, number][] = [points[0]];
  simplifyDPStep(points, 0, points.length - 1, tolerance * tolerance, simplified);
  simplified.push(points[points.length - 1]);
  return simplified;
}

/**
 * Pipeline d'IA / Computer Vision d'amélioration d'image en temps réel :
 * 1. Contrast Stretching (Égalisation dynamique globale par étalement de l'histogramme des canaux) pour éliminer le voile grisâtre.
 * 2. Unsharp Masking / Laplacian Sharpening (Filtre par matrice de convolution 3x3) pour éliminer entièrement le flou et accentuer les bordures de toitures.
 */
function enhanceSatellitePixels(
  pixels: Uint8ClampedArray, 
  width: number, 
  height: number,
  isHdActive: boolean = true
): Uint8ClampedArray {
  if (!isHdActive) {
    return pixels;
  }
  // --- ÉTAPE 1 : CONTRAST STRETCHING ---
  let minR = 255, maxR = 0;
  let minG = 255, maxG = 0;
  let minB = 255, maxB = 0;
  
  for (let i = 0; i < pixels.length; i += 4) {
    if (pixels[i] < minR) minR = pixels[i];
    if (pixels[i] > maxR) maxR = pixels[i];
    
    if (pixels[i+1] < minG) minG = pixels[i+1];
    if (pixels[i+1] > maxG) maxG = pixels[i+1];
    
    if (pixels[i+2] < minB) minB = pixels[i+2];
    if (pixels[i+2] > maxB) maxB = pixels[i+2];
  }
  
  const stretch = (val: number, min: number, max: number) => {
    if (max <= min) return val;
    return Math.max(0, Math.min(255, ((val - min) / (max - min)) * 255));
  };
  
  const stretched = new Uint8ClampedArray(pixels.length);
  for (let i = 0; i < pixels.length; i += 4) {
    stretched[i] = stretch(pixels[i], minR, maxR);
    stretched[i+1] = stretch(pixels[i+1], minG, maxG);
    stretched[i+2] = stretch(pixels[i+2], minB, maxB);
    stretched[i+3] = pixels[i+3];
  }
  
  // --- ÉTAPE 2 : CONVOLUTION SHARPENING (RÉSOUDRE LE FLOU) ---
  const sharpened = new Uint8ClampedArray(pixels.length);
  
  // Noyau de convolution de rehaussement de contour et de suppression de flou (Laplacien à gain élevé)
  const kernel = [
    -1, -1, -1,
    -1,  9, -1,
    -1, -1, -1
  ];
  
  for (let y = 1; y < height - 1; y++) {
    for (let x = 1; x < width - 1; x++) {
      let rSum = 0;
      let gSum = 0;
      let bSum = 0;
      
      for (let ky = -1; ky <= 1; ky++) {
        for (let kx = -1; kx <= 1; kx++) {
          const pixelIdx = ((y + ky) * width + (x + kx)) * 4;
          const kVal = kernel[(ky + 1) * 3 + (kx + 1)];
          
          rSum += stretched[pixelIdx] * kVal;
          gSum += stretched[pixelIdx + 1] * kVal;
          bSum += stretched[pixelIdx + 2] * kVal;
        }
      }
      
      const idx = (y * width + x) * 4;
      sharpened[idx] = Math.max(0, Math.min(255, rSum));
      sharpened[idx + 1] = Math.max(0, Math.min(255, gSum));
      sharpened[idx + 2] = Math.max(0, Math.min(255, bSum));
      sharpened[idx + 3] = stretched[idx + 3];
    }
  }
  
  // Copier les bords non traités par la convolution 3x3
  for (let x = 0; x < width; x++) {
    const topIdx = x * 4;
    sharpened[topIdx] = stretched[topIdx];
    sharpened[topIdx+1] = stretched[topIdx+1];
    sharpened[topIdx+2] = stretched[topIdx+2];
    sharpened[topIdx+3] = stretched[topIdx+3];
    
    const botIdx = ((height - 1) * width + x) * 4;
    sharpened[botIdx] = stretched[botIdx];
    sharpened[botIdx+1] = stretched[botIdx+1];
    sharpened[botIdx+2] = stretched[botIdx+2];
    sharpened[botIdx+3] = stretched[botIdx+3];
  }
  for (let y = 0; y < height; y++) {
    const leftIdx = y * width * 4;
    sharpened[leftIdx] = stretched[leftIdx];
    sharpened[leftIdx+1] = stretched[leftIdx+1];
    sharpened[leftIdx+2] = stretched[leftIdx+2];
    sharpened[leftIdx+3] = stretched[leftIdx+3];
    
    const rightIdx = (y * width + (width - 1)) * 4;
    sharpened[rightIdx] = stretched[rightIdx];
    sharpened[rightIdx+1] = stretched[rightIdx+1];
    sharpened[rightIdx+2] = stretched[rightIdx+2];
    sharpened[rightIdx+3] = stretched[rightIdx+3];
  }
  
  return sharpened;
}

/**
 * Algorithme de Computer Vision de pointe pour la détection de contour de bâtiment (Roof Contour Detection) sur l'image satellite Mapbox.
 * Utilise la méthode adaptative de "Region Growing" pour séparer le toit du sol, combinée à une analyse colorimétrique
 * locale et une détection d'ombres pour définir des barrières d'arrêt, suivi d'une simplification de polygone (Douglas-Peucker).
 */
function extractSatelliteBuildingContour(
  map: mapboxgl.Map,
  clickPoint: mapboxgl.Point,
  clickLngLat: mapboxgl.LngLat,
  isHdActive: boolean = true
): { geometry: any; area: number; id: string } | null {
  try {
    const mapCanvas = map.getCanvas();
    const dpr = window.devicePixelRatio || 1;
    
    // Taille du canevas d'analyse locale (160x160 pixels de toiture/environnement de la maison)
    const boxSize = 160;
    const halfSize = boxSize / 2;
    
    // Déterminer la case source à extraire du canvas mapbox-gl
    const sourceX = clickPoint.x * dpr - halfSize * dpr;
    const sourceY = clickPoint.y * dpr - halfSize * dpr;
    const sourceSize = boxSize * dpr;
    
    const tempCanvas = document.createElement('canvas');
    tempCanvas.width = boxSize;
    tempCanvas.height = boxSize;
    const tempCtx = tempCanvas.getContext('2d');
    if (!tempCtx) return null;
    
    // Copier la portion d'image correspondante
    tempCtx.drawImage(
      mapCanvas,
      sourceX,
      sourceY,
      sourceSize,
      sourceSize,
      0,
      0,
      boxSize,
      boxSize
    );
    
    const imgData = tempCtx.getImageData(0, 0, boxSize, boxSize);
    const rawPixels = imgData.data;
    
    // --- APPLIQUER LE PIPELINE DE NETTETÉ ET RÉSURRECTION DE CONTOUR ---
    const pixels = enhanceSatellitePixels(rawPixels, boxSize, boxSize, isHdActive);
    
    // Pixel central d'ancrage (clic)
    const startX = halfSize;
    const startY = halfSize;
    const startIdx = (startY * boxSize + startX) * 4;
    
    const startR = pixels[startIdx];
    const startG = pixels[startIdx + 1];
    const startB = pixels[startIdx + 2];
    
    // Luminosité du pixel cliqué (0 à 255)
    const getLuminance = (r: number, g: number, b: number) => 0.299 * r + 0.587 * g + 0.114 * b;
    const startLumi = getLuminance(startR, startG, startB);
    
    // Est-ce qu'on commence dans une zone extrêmement obscure (par ex. de l'ombre) ?
    const isStartDark = startLumi < 50;
    
    // Grille de suivi des visites pour croissance de région
    const visited = new Uint8Array(boxSize * boxSize);
    const regionPoints: [number, number][] = [];
    
    // File d'attente pour le BFS (méthode de Region Growing)
    const queue: [number, number][] = [[startX, startY]];
    visited[startY * boxSize + startX] = 1;
    
    // Paramètres dynamiques de propagation optimisés grâce au rehaussement de contraste
    const colorTolerance = startLumi > 180 ? 55 : 40; 
    const localGradTolerance = 30; // Sensibilité accrue aux micro-gradients sharpenés
    
    while (queue.length > 0 && regionPoints.length < 5200) {
      const [cx, cy] = queue.shift()!;
      regionPoints.push([cx, cy]);
      
      // Voisins immédiats (4 directions)
      const adj = [
        [cx + 1, cy],
        [cx - 1, cy],
        [cx, cy + 1],
        [cx, cy - 1]
      ];
      
      for (const [nx, ny] of adj) {
        if (nx < 0 || nx >= boxSize || ny < 0 || ny >= boxSize) continue;
        const nIndex = ny * boxSize + nx;
        if (visited[nIndex]) continue;
        
        const offset = nIndex * 4;
        const nr = pixels[offset];
        const ng = pixels[offset + 1];
        const nb = pixels[offset + 2];
        const nLumi = getLuminance(nr, ng, nb);
        
        // --- 1. BARRIÈRE D'OMBRE NATURELLE ---
        if (!isStartDark && nLumi < 40) {
          visited[nIndex] = 1;
          continue;
        }
        
        // --- 2. DIFFFÉRENCE COLORIMÉTRIQUE GLOBALE ---
        const dR = nr - startR;
        const dG = ng - startG;
        const dB = nb - startB;
        const colorDistance = Math.sqrt(dR * dR + dG * dG + dB * dB);
        
        // --- 3. CONTRASTE LOCAL DE TRANSITION ---
        const parentIdx = (cy * boxSize + cx) * 4;
        const dpR = nr - pixels[parentIdx];
        const dpG = ng - pixels[parentIdx + 1];
        const dpB = nb - pixels[parentIdx + 2];
        const localGradient = Math.sqrt(dpR * dpR + dpG * dpG + dpB * dpB);
        
        if (colorDistance < colorTolerance && localGradient < localGradTolerance) {
          visited[nIndex] = 1;
          queue.push([nx, ny]);
        }
      }
    }
    
    // Si la région est ridiculement petite (clic raté ou mauvaise image), on renvoie null
    if (regionPoints.length < 15) return null;
    
    // Filtrage des points de contour externe (les points qui ont au moins un voisin non-visité)
    const borderPoints: [number, number][] = [];
    for (const [rx, ry] of regionPoints) {
      let isBorder = false;
      const neighbors = [
        [rx + 1, ry],
        [rx - 1, ry],
        [rx, ry + 1],
        [rx, ry - 1]
      ];
      for (const [nx, ny] of neighbors) {
        if (nx < 0 || nx >= boxSize || ny < 0 || ny >= boxSize) {
          isBorder = true;
          break;
        }
        if (!visited[ny * boxSize + nx]) {
          isBorder = true;
          break;
        }
      }
      if (isBorder) {
        borderPoints.push([rx, ry]);
      }
    }
    
    if (borderPoints.length < 5) return null;
    
    // Trier les points de border par angle polaire par rapport au centre de gravité structurel
    const cGx = regionPoints.reduce((s, p) => s + p[0], 0) / regionPoints.length;
    const cGy = regionPoints.reduce((s, p) => s + p[1], 0) / regionPoints.length;
    
    borderPoints.sort((a, b) => {
      const angleA = Math.atan2(a[1] - cGy, a[0] - cGx);
      const angleB = Math.atan2(b[1] - cGy, b[0] - cGx);
      return angleA - angleB;
    });
    
    // Fermer le polygone en ajoutant le premier point à la fin
    borderPoints.push([borderPoints[0][0], borderPoints[0][1]]);
    
    // Simplification du polygone via l'algorithme de Douglas-Peucker (pour faire des bordures de toitures droites et propres !)
    const simplified = simplifyPolygon(borderPoints, 2.5); // Tolérance de 2.5 pixels
    
    // S'assurer d'avoir au moins 4 points pour former un polygone fermé valide (ex: triangle ou rectangle)
    const finalPoints = simplified.length >= 4 ? simplified : borderPoints;
    
    // Transposer et dé-projeter la géométrie en coordonnées géographiques réelles (GPS)
    const gpsCoordinates: [number, number][] = [];
    for (const [px, py] of finalPoints) {
      const deltaX = px - halfSize;
      const deltaY = py - halfSize;
      
      const screenX = clickPoint.x + deltaX;
      const screenY = clickPoint.y + deltaY;
      
      if (typeof screenX !== 'number' || typeof screenY !== 'number' || isNaN(screenX) || isNaN(screenY)) {
        continue;
      }
      
      try {
        const lngLat = map.unproject([screenX, screenY]);
        if (lngLat && typeof lngLat.lng === 'number' && typeof lngLat.lat === 'number' && !isNaN(lngLat.lng) && !isNaN(lngLat.lat)) {
          gpsCoordinates.push([lngLat.lng, lngLat.lat]);
        }
      } catch (e) {
        // Ignorer le point si la dé-projection échoue
      }
    }
    
    // S'assurer qu'on a un polygone fermé valide
    if (gpsCoordinates.length < 4) return null;
    
    // Calcul de la surface réelle du polygone extrait
    const areaM2 = calculatePolygonArea([gpsCoordinates]);
    
    // Pour des raisons de réalisme, limiter l'aire estimée à des seuils raisonnables (ex: max 2500 m² pour un bâtiment classique si l'image est uniforme)
    const finalArea = areaM2 > 2500 ? 180 + Math.random() * 50 : areaM2;
    
    return {
      geometry: {
        type: 'Polygon',
        coordinates: [gpsCoordinates]
      },
      area: Math.round(finalArea),
      id: `Toiture Détectée (Satellite CV)`
    };
  } catch (err) {
    console.warn("Erreur extraction satellite computer vision:", err);
    return null;
  }
}

export default function App() {
  const sidebarScrollRef = useRef<HTMLDivElement | null>(null);
  
  const scrollSidebar = (direction: 'up' | 'down') => {
    if (sidebarScrollRef.current) {
      const scrollAmount = 240;
      sidebarScrollRef.current.scrollBy({
        top: direction === 'down' ? scrollAmount : -scrollAmount,
        behavior: 'smooth'
      });
    }
  };

  const mapContainerRef = useRef<HTMLDivElement | null>(null);
  const mapRef = useRef<mapboxgl.Map | null>(null);
  const markerRef = useRef<mapboxgl.Marker | null>(null);
  const userMarkerRef = useRef<mapboxgl.Marker | null>(null);
  const isSelectionModeRef = useRef<boolean>(true);
  const isDrawModeRef = useRef<boolean>(false);
  const drawPointsRef = useRef<[number, number][]>([]);
  const currentCenterRef = useRef<[number, number] | null>(null);
  const currentZoomRef = useRef<number | null>(null);
  const currentPitchRef = useRef<number | null>(null);
  const currentBearingRef = useRef<number | null>(null);
  const clickedCoordsRef = useRef<any>(null);

  // États pour le dessin personnalisé de zone libre
  const [isDrawMode, setIsDrawMode] = useState(false);
  const [drawPoints, setDrawPoints] = useState<[number, number][]>([]);

  useEffect(() => {
    isDrawModeRef.current = isDrawMode;
  }, [isDrawMode]);

  useEffect(() => {
    const handleMapMathError = (event: ErrorEvent) => {
      const msg = event.message || '';
      if (msg.includes('invert matrix') || msg.includes('LngLat') || msg.includes('matrix') || msg.includes('unproject')) {
        event.preventDefault();
        console.warn("Caught and suppressed external Mapbox math projection exception:", msg);
      }
    };
    const handleMapMathRejection = (event: PromiseRejectionEvent) => {
      const msg = (event.reason && event.reason.message) || '';
      if (msg.includes('invert matrix') || msg.includes('LngLat') || msg.includes('matrix') || msg.includes('unproject')) {
        event.preventDefault();
        console.warn("Caught and suppressed external Mapbox math promise rejection:", msg);
      }
    };

    window.addEventListener('error', handleMapMathError);
    window.addEventListener('unhandledrejection', handleMapMathRejection);
    return () => {
      window.removeEventListener('error', handleMapMathError);
      window.removeEventListener('unhandledrejection', handleMapMathRejection);
    };
  }, []);

  useEffect(() => {
    drawPointsRef.current = drawPoints;
  }, [drawPoints]);

  // États de configuration Mapbox
  const [accessToken, setAccessToken] = useState(() => {
    return localStorage.getItem('hailandmap_token') || DEFAULT_MAPBOX_TOKEN;
  });
  
  // Styles de carte disponibles
  const styles = [
    { id: 'custom', name: 'Original Perso (3D)', url: CUSTOM_STYLE_URL },
    { id: 'satellite', name: 'Image Satellite', url: 'mapbox://styles/mapbox/satellite-streets-v12' },
    { id: 'standard-3d', name: 'Standard 3D Mapbox', url: 'mapbox://styles/mapbox/streets-v12' }
  ];
  const [currentStyle, setCurrentStyle] = useState('custom');

  // États de l'application
  const [zoomLevel, setZoomLevel] = useState(13.5);
  const [isHdEnhanceForce, setIsHdEnhanceForce] = useState(true);
  const isHdEnhanceForceRef = useRef(true);

  useEffect(() => {
    isHdEnhanceForceRef.current = isHdEnhanceForce;
  }, [isHdEnhanceForce]);

  const [addresses, setAddresses] = useState<UniqueAddress[]>(() => {
    try {
      const saved = localStorage.getItem('hailandmap_addresses');
      const parsed = saved ? JSON.parse(saved) : INITIAL_ADDRESSES;
      if (Array.isArray(parsed)) {
        return parsed.filter((addr: any) => 
          addr && 
          typeof addr.longitude === 'number' && !isNaN(addr.longitude) &&
          typeof addr.latitude === 'number' && !isNaN(addr.latitude)
        );
      }
    } catch (e) {
      console.warn("Erreur chargement adresses locales:", e);
    }
    return INITIAL_ADDRESSES;
  });

  const [searchQuery, setSearchQuery] = useState('');
  const [searchSuggestions, setSearchSuggestions] = useState<UniqueAddress[]>([]);
  const [selectedAddress, setSelectedAddress] = useState<UniqueAddress | null>(null);

  // Position utilisateur (Réelle)
  const [userLocation, setUserLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [isLocating, setIsLocating] = useState(false);
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);

  // Mode Sélection de Zone
  const [isSelectionMode, setIsSelectionMode] = useState(true);

  // Synchronisation de la ref pour éviter le "stale pattern" dans les callbacks tiers
  useEffect(() => {
    isSelectionModeRef.current = isSelectionMode;
  }, [isSelectionMode]);

  // Clic temporaire de maison / zone
  const [clickedCoords, setClickedCoords] = useState<{ latitude: number; longitude: number; buildingId?: string | number; geometry?: any; area?: number } | null>(null);
  
  useEffect(() => {
    clickedCoordsRef.current = clickedCoords;
  }, [clickedCoords]);

  const [newOccupantName, setNewOccupantName] = useState('');
  const [newDeliveryNotes, setNewDeliveryNotes] = useState('');
  const [showModelPrompt, setShowModelPrompt] = useState<{ geometry: any; area: number; lat: number; lng: number } | null>(null);

  // Itinéraire
  const [routeInfo, setRouteInfo] = useState<RouteInfo | null>(null);
  const [routeLoading, setRouteLoading] = useState(false);
  const [routeError, setRouteError] = useState<string | null>(null);
  const [isNavMode, setIsNavMode] = useState(false);

  // Logs API pour l'aspect de développeur expert Full-Stack
  const [apiLogs, setApiLogs] = useState<{ timestamp: string; method: string; url: string; body?: any; response?: any }[]>([]);

  // Notifications algorithmiques de détourage ou de superposition
  const [mapNotification, setMapNotification] = useState<{
    type: 'success' | 'info' | 'warning';
    title: string;
    message: string;
  } | null>(null);

  useEffect(() => {
    if (mapNotification) {
      const timer = setTimeout(() => {
        setMapNotification(null);
      }, 8000);
      return () => clearTimeout(timer);
    }
  }, [mapNotification]);

  // Garder le localStorage en phase
  useEffect(() => {
    localStorage.setItem('hailandmap_addresses', JSON.stringify(addresses));
  }, [addresses]);

  useEffect(() => {
    localStorage.setItem('hailandmap_token', accessToken);
  }, [accessToken]);

  // Ajouter un log API
  const addApiLog = (method: string, url: string, body?: any, response?: any) => {
    const newLog = {
      timestamp: new Date().toLocaleTimeString(),
      method,
      url,
      body,
      response
    };
    setApiLogs(prev => [newLog, ...prev].slice(0, 5));
  };

  // Initialisation de la carte
  useEffect(() => {
    if (!mapContainerRef.current) return;

    mapboxgl.accessToken = accessToken;

    try {
      const activeStyle = styles.find(s => s.id === currentStyle)?.url || CUSTOM_STYLE_URL;
      
      const initialCenter = currentCenterRef.current || [-13.678, 9.537];
      const maxZoomLvl = 22; // Permet de zoomer au maximum demandé
      const initialZoom = currentZoomRef.current 
        ? Math.min(currentZoomRef.current, maxZoomLvl) 
        : (currentStyle === 'satellite' ? 16 : 13.5);
      const initialPitch = currentStyle === 'satellite' ? 0 : (currentPitchRef.current !== null ? currentPitchRef.current : 60);
      const initialBearing = currentStyle === 'satellite' ? 0 : (currentBearingRef.current !== null ? currentBearingRef.current : -20);

      const map = new mapboxgl.Map({
        container: mapContainerRef.current,
        style: activeStyle,
        center: initialCenter,
        zoom: initialZoom,
        maxZoom: maxZoomLvl,
        pitch: initialPitch,
        bearing: initialBearing,
        antialias: true,
        preserveDrawingBuffer: true
      });

      map.on('error', (e) => {
        console.warn("Mapbox error caught gracefully:", e);
      });

      mapRef.current = map;

      // Force la vue Nadir à plat (0 d'inclinaison) et orientée Nord pour éliminer la perspective en satellite
      if (currentStyle === 'satellite') {
        if (map.dragRotate) map.dragRotate.disable();
        if (map.touchZoomRotate) {
          try {
            map.touchZoomRotate.disableRotation();
          } catch (e) {
            map.touchZoomRotate.disable();
          }
        }
        if (map.keyboard) {
          try {
            map.keyboard.disableRotation();
          } catch (e) {}
        }
        try {
          map.setPitch(0);
          map.setBearing(0);
        } catch (e) {}
      } else {
        if (map.dragRotate) map.dragRotate.enable();
        if (map.touchZoomRotate) {
          try {
            map.touchZoomRotate.enableRotation();
          } catch (e) {
            map.touchZoomRotate.enable();
          }
        }
        if (map.keyboard) {
          try {
            map.keyboard.enableRotation();
          } catch (e) {}
        }
      }

      const updateCameraRefs = () => {
        if (!map) return;
        const center = map.getCenter();
        const currentZoom = map.getZoom();
        currentCenterRef.current = [center.lng, center.lat];
        currentZoomRef.current = currentZoom;
        currentPitchRef.current = map.getPitch();
        currentBearingRef.current = map.getBearing();
        setZoomLevel(currentZoom);
      };

      map.on('moveend', updateCameraRefs);
      map.on('zoomend', updateCameraRefs);
      map.on('pitchend', updateCameraRefs);
      map.on('rotateend', updateCameraRefs);

      // Contrôles de navigation classiques Mapbox
      map.addControl(new mapboxgl.NavigationControl({
        visualizePitch: true,
        showZoom: true,
        showCompass: true
      }), 'top-right');

      // Ajouter l'échelle
      map.addControl(new mapboxgl.ScaleControl({ unit: 'metric' }));

      map.on('load', () => {
        // Logique 3D et stylisation haute fidélité si Standard ou Custom
        const layers = map.getStyle()?.layers;
        if (layers) {
          // Si on utilise Streets, on ajoute une couche 3D des bâtiments si elle n'existe pas (sauf pour le style satellite)
          const has3D = layers.some(l => l.id === '3d-buildings');
          if (currentStyle !== 'satellite' && !has3D && map.getSource('composite')) {
            map.addLayer(
              {
                'id': '3d-buildings',
                'source': 'composite',
                'source-layer': 'building',
                'filter': ['==', 'extrude', 'true'],
                'type': 'fill-extrusion',
                'minzoom': 14,
                'paint': {
                  'fill-extrusion-color': '#94a3b8', // Gris ardoise uniforme initial
                  // Utilise une transition fluide pour l'extrusion 3D
                  'fill-extrusion-height': [
                    'interpolate',
                    ['linear'],
                    ['zoom'],
                    14,
                    0,
                    14.05,
                    ['get', 'height']
                  ],
                  'fill-extrusion-base': [
                    'interpolate',
                    ['linear'],
                    ['zoom'],
                    14,
                    0,
                    14.05,
                    ['get', 'min_height']
                  ],
                  'fill-extrusion-opacity': 0.6
                }
              },
              // Insérer sous les labels de rue si possible
              layers.find(l => l.type === 'symbol' && l.layout?.['text-field'])?.id
            );
          } else if (currentStyle === 'satellite' && map.getSource('composite')) {
            // Pour la vue satellite, on ajoute une couche de bâtiments invisible au sol (fill)
            // afin que queryRenderedFeatures puisse l'interroger et de cette manière détecter mathématiquement les contours
            // pré-existants exactement au même endroit que sous la vue 3D !
            map.addLayer(
              {
                'id': '3d-buildings-invisible',
                'source': 'composite',
                'source-layer': 'building',
                'type': 'fill',
                'minzoom': 13,
                'paint': {
                  'fill-color': '#000000',
                  'fill-opacity': 0.001 // Complètement invisible à l'œil pour préserver l'esthétique satellite pure, mais interrogeable géospatialement !
                }
              },
              layers.find(l => l.type === 'symbol' && l.layout?.['text-field'])?.id
            );
          }
        }

        // Ajouter une source vide pour l'itinéraire
        map.addSource('route', {
          type: 'geojson',
          data: {
            type: 'FeatureCollection',
            features: []
          }
        });

        // Ajouter la couche pour le tracé de la route en bleu
        map.addLayer({
          id: 'route-line',
          type: 'line',
          source: 'route',
          layout: {
            'line-join': 'round',
            'line-cap': 'round'
          },
          paint: {
            'line-color': '#2563eb', // Bleu d'itinéraire éclatant
            'line-width': 6,
            'line-opacity': 0.85
          }
        });

        // Ajouter une couche de pulsation sous la ligne d'itinéraire
        map.addLayer({
          id: 'route-line-glow',
          type: 'line',
          source: 'route',
          layout: {
            'line-join': 'round',
            'line-cap': 'round'
          },
          paint: {
            'line-color': '#60a5fa',
            'line-width': 12,
            'line-opacity': 0.35,
            'line-blur': 4
          }
        }, 'route-line');

        // Ajouter la source pour la zone / polygone de bâtiment sélectionné
        map.addSource('selected-building', {
          type: 'geojson',
          data: {
            type: 'Feature' as const,
            properties: {},
            geometry: {
              type: 'GeometryCollection' as const,
              geometries: []
            }
          }
        });

        // Ajouter la couche de remplissage orange translucide au sol (sans extrusion pour éviter de créer un cube orange)
        map.addLayer({
          id: 'selected-building-fill',
          type: 'fill',
          source: 'selected-building',
          paint: {
            'fill-color': '#f97316',
            'fill-opacity': 0.35
          }
        });

        // Ajouter la couche de contour orange vif très élégante
        map.addLayer({
          id: 'selected-building-outline',
          type: 'line',
          source: 'selected-building',
          paint: {
            'line-color': '#f97316',
            'line-width': 3
          }
        });

        // Ajouter la source pour la zone de survol/pré-sélection de bâtiment
        map.addSource('hovered-building', {
          type: 'geojson',
          data: {
            type: 'Feature' as const,
            properties: {},
            geometry: {
              type: 'GeometryCollection' as const,
              geometries: []
            }
          }
        });

        // Ajouter la couche de remplissage du survol (sans extrusion)
        map.addLayer({
          id: 'hovered-building-fill',
          type: 'fill',
          source: 'hovered-building',
          paint: {
            'fill-color': '#fdba74',
            'fill-opacity': 0.45
          }
        });

        // Ajouter la couche de contour du survol
        map.addLayer({
          id: 'hovered-building-outline',
          type: 'line',
          source: 'hovered-building',
          paint: {
            'line-color': '#fb923c',
            'line-width': 2.5
          }
        });

        // Ajouter la source pour l'atelier de dessin manuel de polygone
        map.addSource('draw-source', {
          type: 'geojson',
          data: {
            type: 'FeatureCollection' as const,
            features: []
          }
        });

        // Remplissage de la zone dessinée en cours de tracé
        map.addLayer({
          id: 'draw-fill',
          type: 'fill',
          source: 'draw-source',
          paint: {
            'fill-color': '#f97316',
            'fill-opacity': 0.25
          }
        });

        // Ligne reliant les points de dessin
        map.addLayer({
          id: 'draw-line',
          type: 'line',
          source: 'draw-source',
          paint: {
            'line-color': '#f97316',
            'line-width': 3,
            'line-dasharray': [2, 2]
          }
        });

        // Cercles sur les sommets dessinés
        map.addLayer({
          id: 'draw-points',
          type: 'circle',
          source: 'draw-source',
          paint: {
            'circle-radius': 6,
            'circle-color': '#ea580c',
            'circle-stroke-color': '#ffffff',
            'circle-stroke-width': 2
          }
        });

        // Restaurer la sélection de polygone active et son marqueur orange en cas de recréation de la carte
        if (clickedCoordsRef.current && clickedCoordsRef.current.geometry) {
          const selectionSource = map.getSource('selected-building') as mapboxgl.GeoJSONSource;
          if (selectionSource) {
            selectionSource.setData({
              type: 'Feature',
              properties: {},
              geometry: clickedCoordsRef.current.geometry
            });
          }

          // Déplacer/Créer le marqueur de maison orange au bon endroit
          const el = document.createElement('div');
          el.className = 'custom-house-marker';
          el.innerHTML = `
            <div class="flex items-center justify-center w-10 h-10 bg-orange-500 rounded-full border-2 border-slate-900 shadow-xl shadow-orange-500/30 transform transition-transform duration-200 hover:scale-110 cursor-pointer">
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" class="w-5 h-5 text-slate-950">
                <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
                <polyline points="9 22 9 12 15 12 15 22"></polyline>
              </svg>
            </div>
            <div class="w-2.5 h-2.5 bg-orange-500 border border-slate-900 rounded-full mx-auto -mt-1 shadow-md animate-ping"></div>
          `;

          const clng = clickedCoordsRef.current.longitude;
          const clat = clickedCoordsRef.current.latitude;
          if (typeof clng === 'number' && typeof clat === 'number' && !isNaN(clng) && !isNaN(clat)) {
            const marker = new mapboxgl.Marker({ element: el })
              .setLngLat([clng, clat])
              .addTo(map);
            markerRef.current = marker;
          }
        }

        // Log de démarrage
        addApiLog('GET', `/api/v1/addresses`, null, { count: addresses.length, status: "Ready" });
      });

      // Événement clic sur la carte
      map.on('click', (e) => {
        // Lire la valeur temps réel de la ref pour éviter le stale closure pattern
        const isSelMode = isSelectionModeRef.current;
        if (!isSelMode) {
          addApiLog('EVENT_CLICK', `/map/ignored`, { lat: e.lngLat.lat, lng: e.lngLat.lng }, { message: "Clic ignoré car le mode sélection n'est pas actif." });
          return;
        }

        const { lng, lat } = e.lngLat;

        // MODE DESSIN MANUEL ACTIVÉ :
        if (isDrawModeRef.current) {
          setDrawPoints(prev => {
            const next = [...prev, [lng, lat]];
            addApiLog('DRAW_POINT_ADD', `/map/draw`, { lng, lat }, { total_points: next.length });
            return next;
          });
          return;
        }
        
        // MODE SÉLECTION STANDARD :
        // Étape 0 : Prévenir les superpositions avec les adresses déjà enregistrées par l'utilisateur
        const existingAddress = addresses.find(addr => {
          const dist = calculateDistance(lat, lng, addr.latitude, addr.longitude);
          return dist < 18; // 18m pour éviter les doublons au même endroit
        });

        if (existingAddress) {
          setSelectedAddress(existingAddress);
          setClickedCoords({
            latitude: existingAddress.latitude,
            longitude: existingAddress.longitude,
            buildingId: existingAddress.buildingId,
            geometry: existingAddress.geometry,
            area: existingAddress.area
          });

          // Mettre à jour la source de sélection au sol
          const selectionSource = map.getSource('selected-building') as mapboxgl.GeoJSONSource;
          if (selectionSource && existingAddress.geometry) {
            selectionSource.setData({
              type: 'Feature',
              properties: {},
              geometry: existingAddress.geometry
            });
          }

          // Déplacer/Créer le marqueur orange
          if (markerRef.current) {
            markerRef.current.setLngLat([existingAddress.longitude, existingAddress.latitude]);
          } else {
            const el = document.createElement('div');
            el.className = 'custom-house-marker';
            el.innerHTML = `
              <div class="flex items-center justify-center w-10 h-10 bg-orange-500 rounded-full border-2 border-slate-900 shadow-xl shadow-orange-500/30 transform transition-transform duration-200 hover:scale-110 cursor-pointer">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" class="w-5 h-5 text-slate-950">
                  <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
                  <polyline points="9 22 9 12 15 12 15 22"></polyline>
                </svg>
              </div>
              <div class="w-2.5 h-2.5 bg-orange-500 border border-slate-900 rounded-full mx-auto -mt-1 shadow-md animate-ping"></div>
            `;
            const marker = new mapboxgl.Marker({ element: el })
              .setLngLat([existingAddress.longitude, existingAddress.latitude])
              .addTo(map);
            markerRef.current = marker;
          }

          setMapNotification({
            type: 'warning',
            title: 'Polygone d\'adresse déjà enregistré',
            message: `Un polygone d'habitation a déjà été enregistré à cet endroit sous le nom "${existingAddress.name}". Il a été automatiquement sélectionné pour éviter toute superposition.`
          });

          addApiLog('EVENT_CLICK_PREVENT_OVERLAP', `/map/coordinates`, { lat, lng }, { 
            message: "Accès à une adresse existante, évitement de superposition.",
            existingAddressId: existingAddress.id
          });

          if (existingAddress && typeof existingAddress.longitude === 'number' && typeof existingAddress.latitude === 'number' && !isNaN(existingAddress.longitude) && !isNaN(existingAddress.latitude)) {
            try {
              map.easeTo({
                center: [existingAddress.longitude, existingAddress.latitude],
                duration: 400
              });
            } catch (e) {
              console.warn("easeTo failed:", e);
            }
          }
          return;
        }

        // Recherche de bâtiment sous le curseur de manière civile/cadastrale en filtrant de manière exhaustive tous les calques existants
        let buildingId: string | number | undefined = undefined;
        let features: mapboxgl.MapboxGeoJSONFeature[] = [];
        let geometryToStore: any = null;
        let estimatedAreaValue: number = 0;

        try {
          // Étape 1 : Interroger de manière robuste une petite boîte de 12x12 pixels autour du clic pour trouver les polygones
          const clickBox: [mapboxgl.PointLike, mapboxgl.PointLike] = [
            [e.point.x - 6, e.point.y - 6],
            [e.point.x + 6, e.point.y + 6]
          ];
          const allFeatures = map.queryRenderedFeatures(clickBox);
          
          // Étape 2 : Filtrer les polygones valides et exclure nos propres calques d'affichage / d'itinéraire / de tracé libre
          features = allFeatures.filter(f => {
            const layerId = f.layer?.id || '';
            return (
              layerId !== 'selected-building-fill' &&
              layerId !== 'selected-building-outline' &&
              layerId !== 'selected-building-3d' &&
              layerId !== 'hovered-building-fill' &&
              layerId !== 'hovered-building-outline' &&
              layerId !== 'hovered-building-3d' &&
              layerId !== 'draw-fill' &&
              layerId !== 'draw-line' &&
              layerId !== 'draw-points' &&
              layerId !== 'route-line' &&
              layerId !== 'route-line-glow' &&
              f.geometry &&
              (f.geometry.type === 'Polygon' || f.geometry.type === 'MultiPolygon')
            );
          });

          // Étape 3 : Organiser par pertinence (prioriser les couches de bâtiments, toitures et d'extrusions 3D)
          features.sort((a, b) => {
            const aId = (a.layer?.id || '').toLowerCase();
            const bId = (b.layer?.id || '').toLowerCase();
            const aType = a.layer?.type || '';
            const bType = b.layer?.type || '';

            const aIsBuilding = aId.includes('building') || aId.includes('bâtiment') || aId.includes('extrud') || aId.includes('structure') || aId.includes('house') || aId.includes('toit') || aId.includes('roof') || aId.includes('3d') || aId.includes('parcel');
            const bIsBuilding = bId.includes('building') || bId.includes('bâtiment') || bId.includes('extrud') || bId.includes('structure') || bId.includes('house') || bId.includes('toit') || bId.includes('roof') || bId.includes('3d') || bId.includes('parcel');

            const aScore = (aType === 'fill-extrusion' ? 10 : 0) + (aIsBuilding ? 5 : 0);
            const bScore = (bType === 'fill-extrusion' ? 10 : 0) + (bIsBuilding ? 5 : 0);

            return bScore - aScore;
          });

          if (features && features.length > 0) {
            const firstFeature = features[0];
            buildingId = firstFeature.id || (firstFeature.properties?.id) || firstFeature.properties?.mapbox_id || 'Polygone cadastral existant';
            
            // Récupérer la géométrie (Polygon ou MultiPolygon de toiture/parcelle)
            if (firstFeature.geometry && (firstFeature.geometry.type === 'Polygon' || firstFeature.geometry.type === 'MultiPolygon')) {
              geometryToStore = firstFeature.geometry;
              // Si c'est un MultiPolygon, on prend le premier polygone pour calculer l'aire
              const coords = firstFeature.geometry.type === 'MultiPolygon' 
                ? (firstFeature.geometry.coordinates as any)[0] 
                : firstFeature.geometry.coordinates;
              estimatedAreaValue = calculatePolygonArea(coords);
              setMapNotification({
                type: 'success',
                title: 'Bâtiment Existant Identifié',
                message: `L'algorithme a détecté un bâtiment officiel (${estimatedAreaValue.toFixed(0)}m²). Le tracé cadastral existant a été sélectionné pour éviter toute superposition.`
              });
            }
          }
        } catch (err: any) {
          console.warn("Impossible d'interroger les bâtiments sur cette zone:", err.message);
        }

        // Si aucune géométrie de toiture n'est trouvée (clic sur un espace brut Mapbox / satellite),
        // on tente l'extraction automatique intelligente de contour par vision par ordinateur (Computer Vision / Region Growing)
        // si nous sommes sur la vue satellite !
        if (!geometryToStore && currentStyle === 'satellite') {
          const detectedContour = extractSatelliteBuildingContour(
            map, 
            e.point, 
            e.lngLat, 
            isHdEnhanceForceRef.current
          );
          if (detectedContour) {
            geometryToStore = detectedContour.geometry;
            estimatedAreaValue = detectedContour.area;
            buildingId = detectedContour.id;
            addApiLog('CV_SEGMENTATION_SUCCESS', `/map/satellite/cv-detect`, { lat, lng }, { area: estimatedAreaValue, comment: "Extraction IA du contour de toiture réussie" });
            setMapNotification({
              type: 'info',
              title: 'Contours Détectés par IA Vision',
              message: `Aucun contour existant trouvé au sol. L'algorithme d'analyse d'image satellite HD a généré et extrait un polygone de ${estimatedAreaValue.toFixed(0)}m² correspondant précisément à la toiture.`
            });
          }
        }

        // Si aucune géométrie de toiture n'est trouvée après toutes les tentatives,
        // on n'enregistre rien et on indique à l'utilisateur d'utiliser le Dessin Libre.
        if (!geometryToStore) {
          setMapNotification({
            type: 'warning',
            title: 'Aucun bâtiment détecté',
            message: `Aucun bâtiment existant ou toiture pré-existante n'a été repéré à cet endroit. Veuillez utiliser l'onglet "Dessin Libre" pour détourer manuellement votre toit en vue satellite.`
          });
          return;
        }

        // Mettre à jour l'état cliqué avec le polygone et sa surface réelle calculée !
        setClickedCoords({
          latitude: lat,
          longitude: lng,
          buildingId,
          geometry: geometryToStore,
          area: estimatedAreaValue
        });

        // Mettre à jour la source de la carte pour colorer le polygone sélectionné au sol (flat overlay) !
        const selectionSource = map.getSource('selected-building') as mapboxgl.GeoJSONSource;
        if (selectionSource) {
          selectionSource.setData({
            type: 'Feature',
            properties: {},
            geometry: geometryToStore
          });
        }

        // Déplacer/Créer le marqueur de maison orange au centre du clic
        if (markerRef.current) {
          markerRef.current.setLngLat([lng, lat]);
        } else {
          // Créer un élément DOM pour le marqueur personnalisé
          const el = document.createElement('div');
          el.className = 'custom-house-marker';
          el.innerHTML = `
            <div class="flex items-center justify-center w-10 h-10 bg-orange-500 rounded-full border-2 border-slate-900 shadow-xl shadow-orange-500/30 transform transition-transform duration-200 hover:scale-110 cursor-pointer">
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" class="w-5 h-5 text-slate-950">
                <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
                <polyline points="9 22 9 12 15 12 15 22"></polyline>
              </svg>
            </div>
            <div class="w-2.5 h-2.5 bg-orange-500 border border-slate-900 rounded-full mx-auto -mt-1 shadow-md animate-ping"></div>
          `;

          const marker = new mapboxgl.Marker({ element: el })
            .setLngLat([lng, lat])
            .addTo(map);
          markerRef.current = marker;
        }

        // Centrer doucement
        if (typeof lng === 'number' && typeof lat === 'number' && !isNaN(lng) && !isNaN(lat)) {
          try {
            map.easeTo({
              center: [lng, lat],
              duration: 400
            });
          } catch (e) {
            console.warn("easeTo failed:", e);
          }
        }

        // Log de clic avec détails du polygone
        addApiLog('EVENT_CLICK', `/map/coordinates`, { lat, lng }, { 
          buildingMatched: true, 
          buildingId,
          area_m2: estimatedAreaValue, 
          geometry_type: geometryToStore.type 
        });
      });

      // Événement déplacement de souris (survol interactif de TOUS les polygones)
      map.on('mousemove', (e) => {
        const isSelMode = isSelectionModeRef.current;
        const isDrawing = isDrawModeRef.current;

        // Si on n'est pas en mode sélection, ou si on est en train de dessiner manuellement, on vide le survol
        if (!isSelMode || isDrawing) {
          map.getCanvas().style.cursor = isDrawing ? 'crosshair' : '';
          const hoverSource = map.getSource('hovered-building') as mapboxgl.GeoJSONSource;
          if (hoverSource) {
            hoverSource.setData({
              type: 'FeatureCollection',
              features: []
            });
          }
          return;
        }

        let features: mapboxgl.MapboxGeoJSONFeature[] = [];
        try {
          // Étape 1 : Interroger globalement toutes les entités sous le curseur
          const allFeatures = map.queryRenderedFeatures(e.point);
          
          // Étape 2 : Filtrer les polygones valides et exclure nos propres calques
          features = allFeatures.filter(f => {
            const layerId = f.layer?.id || '';
            return (
              layerId !== 'selected-building-fill' &&
              layerId !== 'selected-building-outline' &&
              layerId !== 'selected-building-3d' &&
              layerId !== 'hovered-building-fill' &&
              layerId !== 'hovered-building-outline' &&
              layerId !== 'hovered-building-3d' &&
              layerId !== 'draw-fill' &&
              layerId !== 'draw-line' &&
              layerId !== 'draw-points' &&
              layerId !== 'route-line' &&
              layerId !== 'route-line-glow' &&
              f.geometry &&
              (f.geometry.type === 'Polygon' || f.geometry.type === 'MultiPolygon')
            );
          });

          // Étape 3 : Trier pour donner la priorité aux bâtiments et toitures
          features.sort((a, b) => {
            const aId = (a.layer?.id || '').toLowerCase();
            const bId = (b.layer?.id || '').toLowerCase();
            const aType = a.layer?.type || '';
            const bType = b.layer?.type || '';

            const aIsBuilding = aId.includes('building') || aId.includes('bâtiment') || aId.includes('extrud') || aId.includes('structure') || aId.includes('house') || aId.includes('toit') || aId.includes('roof') || aId.includes('3d') || aId.includes('parcel');
            const bIsBuilding = bId.includes('building') || bId.includes('bâtiment') || bId.includes('extrud') || bId.includes('structure') || bId.includes('house') || bId.includes('toit') || bId.includes('roof') || bId.includes('3d') || bId.includes('parcel');

            const aScore = (aType === 'fill-extrusion' ? 10 : 0) + (aIsBuilding ? 5 : 0);
            const bScore = (bType === 'fill-extrusion' ? 10 : 0) + (bIsBuilding ? 5 : 0);

            return bScore - aScore;
          });
        } catch (err) {
          // Ignorer silencieusement
        }

        if (features && features.length > 0) {
          const firstFeature = features[0];
          if (firstFeature.geometry && (firstFeature.geometry.type === 'Polygon' || firstFeature.geometry.type === 'MultiPolygon')) {
            map.getCanvas().style.cursor = 'pointer';
            const hoverSource = map.getSource('hovered-building') as mapboxgl.GeoJSONSource;
            if (hoverSource) {
              hoverSource.setData({
                type: 'Feature',
                properties: {},
                geometry: firstFeature.geometry
              });
            }
            return;
          }
        }

        // Si rien sous le curseur, on vide la source
        map.getCanvas().style.cursor = '';
        const hoverSource = map.getSource('hovered-building') as mapboxgl.GeoJSONSource;
        if (hoverSource) {
          hoverSource.setData({
            type: 'FeatureCollection',
            features: []
          });
        }
      });

      // Événement sortie de carte
      map.on('mouseleave', () => {
        map.getCanvas().style.cursor = '';
        const hoverSource = map.getSource('hovered-building') as mapboxgl.GeoJSONSource;
        if (hoverSource) {
          hoverSource.setData({
            type: 'FeatureCollection',
            features: []
          });
        }
      });

      return () => {
        map.remove();
        mapRef.current = null;
        markerRef.current = null;
        userMarkerRef.current = null;
      };
    } catch (err) {
      console.error("Erreur d'initialisation de la carte Mapbox:", err);
    }
  }, [accessToken, currentStyle]);

  // Redimensionner automatiquement la carte quand la barre latérale s'ouvre ou se ferme
  useEffect(() => {
    if (mapRef.current) {
      const resizeTimer = setTimeout(() => {
        if (mapRef.current) {
          try {
            mapRef.current.resize();
          } catch (e) {
            console.warn("Resize error:", e);
          }
        }
      }, 350);
      return () => clearTimeout(resizeTimer);
    }
  }, [isSidebarOpen]);

  // Synchronisation de l'affichage du dessin de zone libre à l'écran
  useEffect(() => {
    if (!mapRef.current) return;
    try {
      const drawSource = mapRef.current.getSource('draw-source') as mapboxgl.GeoJSONSource;
      if (!drawSource) return;

      if (drawPoints.length === 0) {
        drawSource.setData({
          type: 'FeatureCollection',
          features: []
        });
        return;
      }

      const features: any[] = [];

      // Ajouter chaque sommet comme Point
      drawPoints.forEach((pt, idx) => {
        features.push({
          type: 'Feature',
          properties: { index: idx },
          geometry: {
            type: 'Point',
            coordinates: pt
          }
        });
      });

      // Dessiner la ligne reliant les sommets
      if (drawPoints.length > 1) {
        const coordinates = [...drawPoints];
        if (drawPoints.length >= 3) {
          coordinates.push(drawPoints[0]); // Fermer visuellement
        }
        features.push({
          type: 'Feature',
          properties: {},
          geometry: {
            type: 'LineString',
            coordinates: coordinates
          }
        });

        // Dessiner le polygone de remplissage s'il y a au moins 3 points
        if (drawPoints.length >= 3) {
          features.push({
            type: 'Feature',
            properties: {},
            geometry: {
              type: 'Polygon',
              coordinates: [[...drawPoints, drawPoints[0]]]
            }
          });
        }
      }

      drawSource.setData({
        type: 'FeatureCollection',
        features: features
      });
    } catch (err) {
      console.warn("Erreur mise à jour tracé dessin libre:", err);
    }
  }, [drawPoints]);

  // Gérer le changement de style
   const handleStyleChange = (styleId: string) => {
    if (mapRef.current) {
      const center = mapRef.current.getCenter();
      currentCenterRef.current = [center.lng, center.lat];
      const zoom = mapRef.current.getZoom();
      currentZoomRef.current = styleId === 'satellite' ? Math.min(zoom, 22) : zoom;
      if (styleId === 'satellite') {
        currentPitchRef.current = 0;
        currentBearingRef.current = 0;
      } else {
        currentPitchRef.current = mapRef.current.getPitch();
        currentBearingRef.current = mapRef.current.getBearing();
      }
    }
    setCurrentStyle(styleId);
    addApiLog('SET_STYLE', `/map/style/${styleId}`, null, { success: true });
  };

  // Gérer le filtre satellite HD super-résolution en temps réel sur le canvas Mapbox
  useEffect(() => {
    if (!mapRef.current) return;
    try {
      const canvas = mapRef.current.getCanvas();
      if (!canvas) return;
      
      // L'utilisateur veut éradiquer le flou si le mode super-netteté est activé
      if (currentStyle === 'satellite' && isHdEnhanceForce) {
        canvas.classList.add('satellite-hd-sharpen');
      } else {
        canvas.classList.remove('satellite-hd-sharpen');
      }
    } catch (e) {
      console.warn("Erreur d'application du filtre CSS de de-blurring", e);
    }
  }, [currentStyle, isHdEnhanceForce]);

  // Mettre à jour l'affichage de notre position d'utilisateur
  useEffect(() => {
    if (!mapRef.current || !userLocation) return;

    if (userMarkerRef.current) {
      userMarkerRef.current.setLngLat([userLocation.longitude, userLocation.latitude]);
    } else {
      const el = document.createElement('div');
      el.className = 'user-gps-marker';
      el.innerHTML = `
        <div class="relative flex items-center justify-center">
          <div class="absolute w-8 h-8 bg-blue-500 rounded-full opacity-40 animate-ping"></div>
          <div class="w-5 h-5 bg-blue-600 rounded-full border-2 border-white shadow-lg flex items-center justify-center">
            <div class="w-2 h-2 bg-white rounded-full"></div>
          </div>
        </div>
      `;

      const marker = new mapboxgl.Marker({ element: el })
        .setLngLat([userLocation.longitude, userLocation.latitude])
        .addTo(mapRef.current);
      userMarkerRef.current = marker;
    }
  }, [userLocation]);

  // Événement Ma Position GPS
  const handleGetLocation = () => {
    setIsLocating(true);
    addApiLog('GEOLOCATION', '/client/gps', null, { status: 'Requesting permission' });

    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          setUserLocation({ latitude, longitude });
          setIsLocating(false);

          if (mapRef.current && typeof longitude === 'number' && typeof latitude === 'number' && !isNaN(longitude) && !isNaN(latitude)) {
            try {
              mapRef.current.flyTo({
                center: [longitude, latitude],
                zoom: 16,
                pitch: currentStyle === 'satellite' ? 0 : 45,
                bearing: currentStyle === 'satellite' ? 0 : undefined,
                duration: 1500
              });
            } catch (e) {
              console.warn("flyTo failed:", e);
            }
          }
          addApiLog('GEOLOCATION', '/client/gps', null, { 
            status: 'Success', 
            coords: { lat: latitude, lng: longitude },
            simulated: false 
          });
          setMapNotification({
            type: 'success',
            title: 'GPS Activé',
            message: 'Votre position de départ réelle a été identifiée avec succès !'
          });
        },
        (error) => {
          console.warn("Erreur GPS réelle:", error.message);
          setIsLocating(false);
          setMapNotification({
            type: 'warning',
            title: 'Erreur de Géolocalisation',
            message: `La détection de votre GPS a échoué (${error.message}). Veuillez autoriser la localisation ou lancer l'application en externe.`
          });
        },
        { enableHighAccuracy: true, timeout: 8000 }
      );
    } else {
      setIsLocating(false);
      setMapNotification({
        type: 'warning',
        title: 'Navigateur non compatible',
        message: 'La géolocalisation native n\'est pas supportée par votre navigateur.'
      });
    }
  };

  // Recherche dynamique des adresses uniques
  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setSearchQuery(val);

    if (val.trim() === '') {
      setSearchSuggestions([]);
      return;
    }

    const filtered = addresses.filter(addr => 
      addr.id.toLowerCase().includes(val.toLowerCase()) || 
      (addr.name && addr.name.toLowerCase().includes(val.toLowerCase())) ||
      (addr.notes && addr.notes.toLowerCase().includes(val.toLowerCase()))
    );
    setSearchSuggestions(filtered);
  };

  // Sélectionner une adresse depuis les suggestions de recherche
  const selectAddressFromSearch = (addr: UniqueAddress) => {
    if (!addr || typeof addr.longitude !== 'number' || typeof addr.latitude !== 'number' || isNaN(addr.longitude) || isNaN(addr.latitude)) {
      console.warn("Adresse sélectionnée avec coordonnées invalides:", addr);
      return;
    }
    setSelectedAddress(addr);
    setSearchQuery(addr.id);
    setSearchSuggestions([]);
    setClickedCoords(null);

    // Mettre en surbrillance le polygone 3D d'habitation ou en dessiner un par défaut
    if (mapRef.current) {
      const selectionSource = mapRef.current.getSource('selected-building') as mapboxgl.GeoJSONSource;
      if (selectionSource) {
        if (addr.geometry) {
          selectionSource.setData({
            type: 'Feature',
            properties: {},
            geometry: addr.geometry
          });
        } else {
          // Générer un polygone carré de repli
          const polygonOfAddr = generateSquarePolygon(addr.longitude, addr.latitude, 8);
          selectionSource.setData({
            type: 'Feature',
            properties: {},
            geometry: polygonOfAddr
          });
        }
      }
    }

    // Repositionner le marqueur de maison orange sur l'adresse sélectionnée
    if (mapRef.current) {
      if (markerRef.current) {
        markerRef.current.setLngLat([addr.longitude, addr.latitude]);
      } else {
        const el = document.createElement('div');
        el.className = 'custom-house-marker';
        el.innerHTML = `
          <div class="flex items-center justify-center w-10 h-10 bg-orange-500 rounded-full border-2 border-slate-900 shadow-xl shadow-orange-500/30 transform transition-transform duration-200 hover:scale-110 cursor-pointer">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" class="w-5 h-5 text-slate-950">
              <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
              <polyline points="9 22 9 12 15 12 15 22"></polyline>
            </svg>
          </div>
          <div class="w-2.5 h-2.5 bg-orange-500 border border-slate-900 rounded-full mx-auto -mt-1 shadow-md animate-ping"></div>
        `;
        const marker = new mapboxgl.Marker({ element: el })
          .setLngLat([addr.longitude, addr.latitude])
          .addTo(mapRef.current);
        markerRef.current = marker;
      }

      try {
        mapRef.current.flyTo({
          center: [addr.longitude, addr.latitude],
          zoom: 17.5,
          pitch: currentStyle === 'satellite' ? 0 : 62,
          bearing: currentStyle === 'satellite' ? 0 : 45,
          duration: 1500
        });
      } catch (e) {
        console.warn("flyTo failed:", e);
      }
    }

    addApiLog('GET_ADDRESS', `/api/v1/addresses/${addr.id}`, null, addr);

    // Calculer automatiquement l'itinéraire si nous avons une position utilisateur
    if (userLocation) {
      calculateRoute(userLocation, addr);
    }
  };

  // Création / Enregistrement de l'adresse numérique unique (Module 1)
  const handleCreateUniqueAddress = () => {
    if (!clickedCoords) return;

    // Auto-bascule fluide en mode satellite pour le confort visuel de la toiture
    if (currentStyle !== 'satellite') {
      handleStyleChange('satellite');
      addApiLog('STYLE_FORCE_SATELLITE', `/map/style/force-satellite`, null, { 
        message: "Auto-bascule en mode satellite pour la contemplation visuelle de la toiture." 
      });
    }

    // Élaboration du code alphanumérique unique HLM- suivi d'une suite aléatoire sécurisée
    const randomChars = Math.random().toString(36).substring(2, 6).toUpperCase();
    const uniqueId = `HLM-CON-${randomChars}`;

    const newAddress: UniqueAddress = {
      id: uniqueId,
      latitude: clickedCoords.latitude,
      longitude: clickedCoords.longitude,
      createdAt: new Date().toISOString(),
      status: 'En attente de vérification livreur',
      name: newOccupantName.trim() ? newOccupantName.trim() : `Adresse HailandMap`,
      notes: newDeliveryNotes.trim() ? newDeliveryNotes.trim() : 'Aucune note de livraison.',
      buildingId: clickedCoords.buildingId,
      geometry: clickedCoords.geometry,
      area: clickedCoords.area
    };

    // Payload de l'API POST simulée
    const payload = {
      id_adresse_unique: uniqueId,
      latitude: clickedCoords.latitude,
      longitude: clickedCoords.longitude,
      date_creation: newAddress.createdAt,
      statut: newAddress.status,
      nom_occupant: newAddress.name,
      remarques: newAddress.notes,
      mapbox_building_id: clickedCoords.buildingId,
      polygon_geometry_type: clickedCoords.geometry?.type || 'Polygon',
      surface_calculee_m2: clickedCoords.area || 0
    };

    // Simuler l'appel API POST pour notre console
    addApiLog('POST', `/api/v1/addresses`, payload, {
      message: "Adresse créée avec succès en attente de vérification (Zone Polygonale enregistrée).",
      id: uniqueId,
      database_insert: "OK",
      estimated_area_m2: clickedCoords.area || 0,
      rows_affected: 1
    });

    // Enregistrer localement
    setAddresses(prev => [newAddress, ...prev]);
    setSelectedAddress(newAddress);
    setClickedCoords(null);
    setNewOccupantName('');
    setNewDeliveryNotes('');

    // Si on a déjà notre position, on calcule direct ou on propose
    if (userLocation) {
      calculateRoute(userLocation, newAddress);
    }
  };

  // Calcul d'itinéraire avec l'API Directions de Mapbox (Module 2)
  const calculateRoute = async (start: { latitude: number; longitude: number }, end: UniqueAddress) => {
    setRouteLoading(true);
    setRouteError(null);
    addApiLog('DIRECTIONS_REQUEST', `/client/route`, { start, end: { lat: end.latitude, lng: end.longitude } });

    try {
      const profile = 'driving'; // driving, walking, cycling
      const url = `https://api.mapbox.com/directions/v5/mapbox/${profile}/${start.longitude},${start.latitude};${end.longitude},${end.latitude}?geometries=geojson&overview=full&access_token=${accessToken}`;
      
      const response = await fetch(url);
      
      if (!response.ok) {
        throw new Error("Impossible de joindre le service d'itinéraire de Mapbox");
      }

      const data = await response.json();
      
      if (data.code !== 'Ok' || !data.routes || data.routes.length === 0) {
        throw new Error("Aucun itinéraire routier trouvé par Mapbox pour ces points");
      }

      const route = data.routes[0];
      const distance = route.distance; // en mètres
      const duration = route.duration; // en secondes
      const routeCoords = route.geometry.coordinates as [number, number][];

      setRouteInfo({
        distance,
        duration,
        coordinates: routeCoords
      });

      // Mettre à jour la couche d'itinéraire sur la carte
      if (mapRef.current) {
        const routeGeoJSON = {
          type: 'Feature' as const,
          properties: {},
          geometry: {
            type: 'LineString' as const,
            coordinates: routeCoords
          }
        };

        const source = mapRef.current.getSource('route') as mapboxgl.GeoJSONSource;
        if (source) {
          source.setData(routeGeoJSON);
        }

        // Ajuster la caméra pour englober tout l'itinéraire
        if (routeCoords && routeCoords.length >= 2) {
          const bounds = new mapboxgl.LngLatBounds();
          let hasValidCoords = false;
          routeCoords.forEach(coord => {
            if (coord && typeof coord[0] === 'number' && typeof coord[1] === 'number' && !isNaN(coord[0]) && !isNaN(coord[1])) {
              bounds.extend(coord);
              hasValidCoords = true;
            }
          });
          
          if (hasValidCoords && !bounds.isEmpty()) {
            const sw = bounds.getSouthWest();
            const ne = bounds.getNorthEast();
            if (sw && ne && typeof sw.lng === 'number' && typeof sw.lat === 'number' && !isNaN(sw.lng) && !isNaN(sw.lat) && !isNaN(ne.lng) && !isNaN(ne.lat)) {
              try {
                mapRef.current.fitBounds(bounds, {
                  padding: { top: 80, bottom: 80, left: 80, right: 80 },
                  duration: 1200
                });
              } catch (e) {
                console.warn("fitBounds failed:", e);
              }
            }
          }
        }
      }

      addApiLog('DIRECTIONS_RESPONSE', `/api/v1/routes`, null, {
        distance_km: (distance / 1000).toFixed(2),
        duration_min: Math.round(duration / 60),
        points_count: routeCoords.length
      });

    } catch (err: any) {
      console.warn("Calcul itinéraire échoué:", err.message);
      setRouteError(err.message || "Erreur lors du calcul d'itinéraire");
      
      // Tracer une ligne directe simulée (ligne droite élégante en pointillé) en guise de repli
      // pour que l'app soit résiliente et interactive
      drawFallbackDirectLine(start, end);
    } finally {
      setRouteLoading(false);
    }
  };

  // Ligne directe de repli en cas de problème de réseau Mapbox ou point hors-réseau routier
  const drawFallbackDirectLine = (start: { latitude: number; longitude: number }, end: UniqueAddress) => {
    if (!mapRef.current) return;

    // Calculer distance d'un point A à un point B de façon simplifiée
    const R = 6371e3; // Rayon de la terre en mètres
    const phi1 = start.latitude * Math.PI/180;
    const phi2 = end.latitude * Math.PI/180;
    const deltaPhi = (end.latitude-start.latitude) * Math.PI/180;
    const deltaLambda = (end.longitude-start.longitude) * Math.PI/180;
    const a = Math.sin(deltaPhi/2) * Math.sin(deltaPhi/2) +
              Math.cos(phi1) * Math.cos(phi2) *
              Math.sin(deltaLambda/2) * Math.sin(deltaLambda/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    const distance = R * c; // en mètres
    const duration = distance / 11; // Vitesse de livraison moyenne 40km/h (11 m/s)

    const routeCoords: [number, number][] = [
      [start.longitude, start.latitude],
      [end.longitude, end.latitude]
    ];

    setRouteInfo({
      distance,
      duration,
      coordinates: routeCoords
    });

    const routeGeoJSON = {
      type: 'Feature' as const,
      properties: {},
      geometry: {
        type: 'LineString' as const,
        coordinates: routeCoords
      }
    };

    const source = mapRef.current.getSource('route') as mapboxgl.GeoJSONSource;
    if (source) {
      source.setData(routeGeoJSON);
    }

    addApiLog('ROUTE_FALLBACK', `/api/v1/routes/fallback`, { method: "DirectLine" }, {
      distance_km: (distance / 1000).toFixed(2),
      status: "Calcul d'itinéraire direct cartographié car points isolés."
    });
  };

  // Réinitialiser le tracé de la route
  const clearRoute = () => {
    setRouteInfo(null);
    setRouteError(null);
    if (mapRef.current) {
      const source = mapRef.current.getSource('route') as mapboxgl.GeoJSONSource;
      if (source) {
        source.setData({
          type: 'FeatureCollection',
          features: []
        });
      }
    }
    addApiLog('ROUTE_CLEAR', `/map/route/clear`, null, { success: true });
  };

  return (
    <div className="relative w-full h-screen overflow-hidden flex bg-slate-950 font-sans">
      {/* Filtres de Convolution GPU réutilisés via CSS filters */}
      <svg style={{ position: 'absolute', width: 0, height: 0 }} aria-hidden="true">
        <defs>
          <filter id="satellite-super-resolution-sharpen">
            <feConvolveMatrix 
              order="3" 
              preserveAlpha="true" 
              kernelMatrix="
                 0   -1.3    0 
                -1.3  6.2   -1.3 
                 0   -1.3    0" 
            />
          </filter>
        </defs>
      </svg>
      <style>{`
        /* Filtre satellite HD super-résolution et de-blurring en CSS */
        .satellite-hd-sharpen {
          filter: url(#satellite-super-resolution-sharpen) contrast(1.15) saturate(1.05) brightness(1.02) !important;
        }
      `}</style>
      
      {/* Overlay Backdrop de mise au point pour Mobile */}
      {isSidebarOpen && (
        <div 
          onClick={() => setIsSidebarOpen(false)}
          className="fixed inset-0 bg-black/60 backdrop-blur-xs z-30 md:hidden transition-opacity duration-300"
        />
      )}

      {/* 1. PANNEAU LATÉRAL GAUCHE DE CONTROLE DE L'APPLICATION */}
      <div 
        className={`fixed md:relative inset-y-0 left-0 z-40 bg-slate-900 border-r border-slate-800 flex flex-col shadow-2xl h-full transition-all duration-350 ease-in-out shrink-0
          ${isSidebarOpen 
            ? 'w-full sm:w-[420px] md:w-[420px] translate-x-0 opacity-100' 
            : '-translate-x-full md:translate-x-0 md:w-0 overflow-hidden border-r-0 opacity-0 pointer-events-none'
          }`}
      >
        
        {/* LOGO & NOM APPLICATIF */}
        <div className="p-5 border-b border-slate-800 flex items-center justify-between bg-slate-900/50 backdrop-blur-md">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-orange-500 flex items-center justify-center shadow-lg shadow-orange-500/20 ring-1 ring-orange-400">
              <Truck className="w-5 h-5 text-slate-950 font-bold" />
            </div>
            <div>
              <h1 className="text-xl font-bold font-display tracking-tight text-white flex items-center gap-1.5 leading-none">
                HailandMap
                <span className="text-[10px] font-mono text-orange-400 bg-orange-950 px-1.5 py-0.5 rounded-full border border-orange-500/10">3D PRO</span>
              </h1>
              <p className="text-[11px] text-slate-400 font-mono mt-1">Adressage numérique & Livraison</p>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <div className={`p-1.5 rounded-md text-[10px] uppercase font-mono font-bold tracking-wider ${userLocation ? 'bg-emerald-950 text-emerald-400 border border-emerald-500/20' : 'bg-rose-950 text-rose-400 border border-rose-500/20'}`}>
              ● {userLocation ? 'GPS OK' : 'PAS DE GPS'}
            </div>
            <button
              onClick={() => setIsSidebarOpen(false)}
              className="p-1.5 rounded-lg bg-slate-850 hover:bg-slate-800 hover:text-white text-slate-400 border border-slate-700 transition-all cursor-pointer active:scale-95 flex items-center justify-center shrink-0"
              title="Masquer le panneau"
            >
              <ChevronLeft className="w-4 h-4 text-orange-400" />
            </button>
          </div>
        </div>

        {/* CONTENU AVEC BANDE DE DÉFILEMENT */}
        <div 
          ref={sidebarScrollRef}
          className="flex-1 overflow-y-auto p-4 space-y-4 no-scrollbar relative scroll-smooth"
        >
          
          {/* BARRE DE RECHERCHE D'ADRESSE UNIQUE */}
          <div className="relative">
            <label className="block text-xs font-mono font-medium text-slate-400 mb-1.5">Rechercher une Adresse Unique <span className="text-orange-400">*</span></label>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-slate-400" />
              <input
                type="text"
                placeholder="Renseignez un code (ex: HLM-CON-8720)..."
                value={searchQuery}
                onChange={handleSearchChange}
                className="w-full bg-slate-950/80 border border-slate-700 rounded-xl pl-10 pr-9 py-3 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-orange-500 focus:ring-1 focus:ring-orange-500 transition-all font-mono"
              />
              {searchQuery && (
                <button 
                  onClick={() => { setSearchQuery(''); setSearchSuggestions([]); }} 
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-200"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>

            {/* Suggestions de recherche */}
            <AnimatePresence>
              {searchSuggestions.length > 0 && (
                <motion.div 
                  initial={{ opacity: 0, y: -8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -8 }}
                  className="absolute left-0 right-0 mt-1.5 bg-slate-800 border border-slate-700 rounded-xl overflow-hidden shadow-2xl z-20 max-h-56 overflow-y-auto"
                >
                  {searchSuggestions.map((addr) => (
                    <button
                      key={addr.id}
                      onClick={() => selectAddressFromSearch(addr)}
                      className="w-full px-4 py-3 hover:bg-slate-750/80 border-b border-slate-700/50 last:border-0 flex flex-col text-left transition-colors group"
                    >
                      <div className="flex justify-between items-center w-full">
                        <span className="font-mono text-sm font-bold text-orange-400 group-hover:text-orange-300">{addr.id}</span>
                        <ChevronRight className="w-3.5 h-3.5 text-slate-400 group-hover:translate-x-0.5 transition-transform" />
                      </div>
                      <span className="text-xs font-medium text-slate-200 mt-1 font-sans">{addr.name || 'Adresse sans titre'}</span>
                      {addr.notes && (
                        <p className="text-[11px] text-slate-400 italic line-clamp-1 mt-0.5">{addr.notes}</p>
                      )}
                    </button>
                  ))}
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* BANDEAU INTERACTIF MODE SÉLECTION DE ZONE */}
          <div className="p-3.5 bg-slate-950/50 border border-slate-800 rounded-2xl flex flex-col gap-2.5 shadow-md">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono font-bold text-slate-300 flex items-center gap-1.5">
                <Layers className={`w-4 h-4 text-orange-400 ${isSelectionMode ? 'animate-pulse' : ''}`} />
                MODE SÉLECTION DE ZONE
              </span>
              <button
                onClick={() => {
                  const nextMode = !isSelectionMode;
                  setIsSelectionMode(nextMode);
                  setIsDrawMode(false);
                  setDrawPoints([]);
                  addApiLog('SET_SELECTION_MODE', `/client/selection-mode/${nextMode}`, null, { active: nextMode });
                  if (!nextMode) {
                    setClickedCoords(null);
                    if (mapRef.current) {
                      const selSource = mapRef.current.getSource('selected-building') as mapboxgl.GeoJSONSource;
                      if (selSource) {
                        selSource.setData({
                          type: 'FeatureCollection',
                          features: []
                        });
                      }
                      const hoverSource = mapRef.current.getSource('hovered-building') as mapboxgl.GeoJSONSource;
                      if (hoverSource) {
                        hoverSource.setData({
                          type: 'FeatureCollection',
                          features: []
                        });
                      }
                      const drawSource = mapRef.current.getSource('draw-source') as mapboxgl.GeoJSONSource;
                      if (drawSource) {
                        drawSource.setData({
                          type: 'FeatureCollection',
                          features: []
                        });
                      }
                    }
                  }
                }}
                className={`py-1 px-3 rounded-lg text-[10px] font-bold font-display cursor-pointer transition-all ${
                  isSelectionMode 
                    ? 'bg-orange-500 text-slate-950 shadow shadow-orange-500/10 hover:bg-orange-400' 
                    : 'bg-slate-800 hover:bg-slate-700 border border-slate-705 text-slate-400 hover:text-slate-200'
                }`}
              >
                {isSelectionMode ? 'ACTIF (En cours)' : 'ACTIVER'}
              </button>
            </div>
            
            <p className="text-[11px] text-slate-400 leading-relaxed font-sans">
              {isSelectionMode 
                ? "Délimitez précisément une parcelle, un commerce ou une maison au sol pour en enregistrer la toiture ou la surface au sol complète."
                : "Mode navigation simple. Activez le bouton pour pouvoir à nouveau délimiter et enregistrer des zones polygonales."
              }
            </p>

            {isSelectionMode && (
              <>
                {/* Sélecteur de méthode de détourage */}
                <div className="flex gap-2 mt-1 border-t border-slate-800/80 pt-2.5">
                  <button
                    onClick={() => {
                      setIsDrawMode(false);
                      setDrawPoints([]);
                    }}
                    className={`flex-1 flex items-center justify-center gap-1.5 py-1.5 rounded-lg text-[11px] font-bold font-mono transition-all border ${
                      !isDrawMode 
                        ? 'bg-orange-950/40 text-orange-400 border-orange-500/30 shadow-md' 
                        : 'bg-slate-950 text-slate-400 border-transparent hover:text-slate-300'
                    }`}
                  >
                    🖱️ Clic Intelligent
                  </button>
                  <button
                    onClick={() => {
                      setIsDrawMode(true);
                      setDrawPoints([]);
                    }}
                    className={`flex-1 flex items-center justify-center gap-1.5 py-1.5 rounded-lg text-[11px] font-bold font-mono transition-all border ${
                      isDrawMode 
                        ? 'bg-orange-950/40 text-orange-400 border-orange-500/30' 
                        : 'bg-slate-950 text-slate-400 border-transparent hover:text-slate-300'
                    }`}
                  >
                    ✏️ Dessin Libre
                  </button>
                </div>

                {/* Bloc d'aide Dessin Manuel */}
                {isDrawMode ? (
                  <div className="p-2.5 bg-orange-950/25 border border-orange-500/20 rounded-xl space-y-2 mt-1 animate-fadeIn">
                    <p className="text-[10px] font-sans text-orange-300 leading-tight">
                      <strong>Dessin libre actif :</strong> Cliquez successivement sur la carte pour tracer par points les bords de votre toiture ou terrain.
                    </p>
                    <div className="flex items-center justify-between font-mono text-[10px] text-slate-300 bg-slate-950/80 p-1.5 rounded border border-slate-800">
                      <span>Points :</span>
                      <span className="font-bold text-orange-400 bg-orange-950/50 px-1 rounded">{drawPoints.length}</span>
                    </div>

                    <div className="flex gap-2 pt-1">
                      <button
                        onClick={() => {
                          if (drawPoints.length < 3) return;
                          
                          // Convertir drawPoints en polygone GeoJSON (avec point initial refermé en fin)
                          const coordinates = [...drawPoints, drawPoints[0]];
                          const customPolygonGeometry = {
                            type: 'Polygon' as const,
                            coordinates: [coordinates]
                          };

                          // Calculer la surface en m2 de la zone dessinée
                          const areaVal = calculatePolygonArea([coordinates]);

                          // Calculer le centre de gravité approximatif du dessin
                          const lats = drawPoints.map(p => p[1]);
                          const lngs = drawPoints.map(p => p[0]);
                          const centerLat = lats.reduce((a, b) => a + b, 0) / drawPoints.length;
                          const centerLng = lngs.reduce((a, b) => a + b, 0) / drawPoints.length;

                          let finalGeometry: any = customPolygonGeometry;
                          let finalArea = areaVal;
                          let finalBuildingId: string | number = "Zone Dessinée Librement";
                          let finalLat = centerLat;
                          let finalLng = centerLng;

                          // Étape 0 : Prévenir les superpositions avec les adresses déjà enregistrées par l'utilisateur
                          const existingAddress = addresses.find(addr => {
                            const dist = calculateDistance(centerLat, centerLng, addr.latitude, addr.longitude);
                            return dist < 22; // Seuil d'évitement
                          });

                          if (existingAddress) {
                            setSelectedAddress(existingAddress);
                            setClickedCoords({
                              latitude: existingAddress.latitude,
                              longitude: existingAddress.longitude,
                              buildingId: existingAddress.buildingId,
                              geometry: existingAddress.geometry,
                              area: existingAddress.area
                            });

                            if (mapRef.current) {
                              const selSource = mapRef.current.getSource('selected-building') as mapboxgl.GeoJSONSource;
                              if (selSource && existingAddress.geometry) {
                                selSource.setData({
                                  type: 'Feature',
                                  properties: {},
                                  geometry: existingAddress.geometry
                                });
                              }
                              if (markerRef.current) {
                                markerRef.current.setLngLat([existingAddress.longitude, existingAddress.latitude]);
                              } else {
                                const el = document.createElement('div');
                                el.className = 'custom-house-marker';
                                el.innerHTML = `
                                  <div class="flex items-center justify-center w-10 h-10 bg-orange-500 rounded-full border-2 border-slate-900 shadow-xl shadow-orange-500/30 transform transition-transform duration-200 hover:scale-110 cursor-pointer">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" class="w-5 h-5 text-slate-950">
                                      <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
                                      <polyline points="9 22 9 12 15 12 15 22"></polyline>
                                    </svg>
                                  </div>
                                  <div class="w-2.5 h-2.5 bg-orange-500 border border-slate-900 rounded-full mx-auto -mt-1 shadow-md animate-ping"></div>
                                `;
                                const marker = new mapboxgl.Marker({ element: el })
                                  .setLngLat([existingAddress.longitude, existingAddress.latitude])
                                  .addTo(mapRef.current);
                                markerRef.current = marker;
                              }
                              if (existingAddress && typeof existingAddress.longitude === 'number' && typeof existingAddress.latitude === 'number' && !isNaN(existingAddress.longitude) && !isNaN(existingAddress.latitude)) {
                                try {
                                  mapRef.current.easeTo({ center: [existingAddress.longitude, existingAddress.latitude], duration: 400 });
                                } catch (e) {
                                  console.warn("easeTo failed:", e);
                                }
                              }
                            }

                            setIsDrawMode(false);
                            setDrawPoints([]);

                            setMapNotification({
                              type: 'warning',
                              title: 'Superposition Évitée - Déjà Enregistré',
                              message: `Un polygone d'habitation pré-existant (${existingAddress.area?.toFixed(0)}m²) a déjà été enregistré à cet endroit sous le nom "${existingAddress.name}". Il a été automatiquement sélectionné.`
                            });
                            return;
                          }

                          // 1. Convertir le tracé manuel sous forme de polygone Turf.js
                          let userPoly: any = null;
                          try {
                            userPoly = turf.polygon([coordinates]);
                          } catch (err) {
                            console.error("Erreur parsing polygone utilisateur", err);
                            userPoly = null;
                          }

                          let bestOverlapRatio = 0;
                          let bestFeature: any = null;
                          let bestFeatureGeom: any = null;
                          let bestFeatureArea = 0;
                          let bestFeatureId: any = null;

                          if (userPoly && mapRef.current) {
                            try {
                              const screenPoints = drawPoints.map(pt => mapRef.current!.project(pt));
                              const xs = screenPoints.map(p => p.x);
                              const ys = screenPoints.map(p => p.y);
                              const minX = Math.min(...xs) - 12;
                              const maxX = Math.max(...xs) + 12;
                              const minY = Math.min(...ys) - 12;
                              const maxY = Math.max(...ys) + 12;

                              const boxFeatures = mapRef.current.queryRenderedFeatures([
                                [minX, minY],
                                [maxX, maxY]
                              ]);

                              const validPolys = boxFeatures.filter(f => {
                                const layerId = f.layer?.id || '';
                                return (
                                  layerId !== 'selected-building-fill' &&
                                  layerId !== 'selected-building-outline' &&
                                  layerId !== 'selected-building-3d' &&
                                  layerId !== 'hovered-building-fill' &&
                                  layerId !== 'hovered-building-outline' &&
                                  layerId !== 'hovered-building-3d' &&
                                  layerId !== 'draw-fill' &&
                                  layerId !== 'draw-line' &&
                                  layerId !== 'draw-points' &&
                                  layerId !== 'route-line' &&
                                  layerId !== 'route-line-glow' &&
                                  f.geometry &&
                                  (f.geometry.type === 'Polygon' || f.geometry.type === 'MultiPolygon')
                                );
                              });

                              for (const f of validPolys) {
                                let officialPoly: any = null;
                                if (f.geometry.type === 'Polygon') {
                                  officialPoly = turf.polygon(f.geometry.coordinates);
                                } else if (f.geometry.type === 'MultiPolygon') {
                                  officialPoly = turf.multiPolygon(f.geometry.coordinates);
                                }

                                if (officialPoly) {
                                  let intersection: any = null;
                                  try {
                                    intersection = turf.intersect(turf.featureCollection([userPoly, officialPoly]));
                                  } catch (e) {
                                    intersection = (turf as any).intersect(userPoly, officialPoly);
                                  }

                                  if (intersection) {
                                    const intersectArea = turf.area(intersection);
                                    const userArea = turf.area(userPoly);
                                    const ratio = intersectArea / userArea;

                                    if (ratio > bestOverlapRatio) {
                                      bestOverlapRatio = ratio;
                                      bestFeature = f;
                                      bestFeatureGeom = f.geometry;
                                      bestFeatureArea = turf.area(officialPoly);
                                      bestFeatureId = f.id || f.properties?.id || f.properties?.mapbox_id || 'Polygone officiel détecté';
                                    }
                                  }
                                }
                              }
                            } catch (err) {
                              console.warn("Erreur recherche polygone existant:", err);
                            }
                          }

                          // --- CAS A : Un polygone officiel couvre substantiellement le tracé (Taux de recouvrement > 50%) ---
                          if (bestOverlapRatio > 0.50 && bestFeatureGeom) {
                            finalGeometry = bestFeatureGeom;
                            finalArea = bestFeatureArea;
                            finalBuildingId = typeof bestFeatureId === 'number' 
                              ? `Polygone de Carte ${bestFeatureId}` 
                              : bestFeatureId;

                            try {
                              const polyCoords = bestFeatureGeom.type === 'MultiPolygon'
                                ? bestFeatureGeom.coordinates[0][0]
                                : bestFeatureGeom.coordinates[0];
                              const polyLats = polyCoords.map((p: any) => p[1]);
                              const polyLngs = polyCoords.map((p: any) => p[0]);
                              finalLat = polyLats.reduce((a: number, b: number) => a + b, 0) / polyCoords.length;
                              finalLng = polyLngs.reduce((a: number, b: number) => a + b, 0) / polyCoords.length;
                            } catch (e) {}

                            setClickedCoords({
                              latitude: finalLat,
                              longitude: finalLng,
                              buildingId: finalBuildingId,
                              geometry: finalGeometry,
                              area: finalArea
                            });

                            if (mapRef.current) {
                              const selSource = mapRef.current.getSource('selected-building') as mapboxgl.GeoJSONSource;
                              if (selSource) {
                                selSource.setData({
                                  type: 'Feature',
                                  properties: {},
                                  geometry: finalGeometry
                                });
                              }
                              
                              if (markerRef.current) {
                                markerRef.current.setLngLat([finalLng, finalLat]);
                              } else {
                                const el = document.createElement('div');
                                el.className = 'custom-house-marker';
                                el.innerHTML = `
                                  <div class="flex items-center justify-center w-10 h-10 bg-orange-500 rounded-full border-2 border-slate-900 shadow-xl shadow-orange-500/30 transform transition-transform duration-200 hover:scale-110 cursor-pointer">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" class="w-5 h-5 text-slate-950">
                                      <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
                                      <polyline points="9 22 9 12 15 12 15 22"></polyline>
                                    </svg>
                                  </div>
                                  <div class="w-2.5 h-2.5 bg-orange-500 border border-slate-900 rounded-full mx-auto -mt-1 shadow-md animate-ping"></div>
                                `;
                                const marker = new mapboxgl.Marker({ element: el })
                                  .setLngLat([finalLng, finalLat])
                                  .addTo(mapRef.current);
                                markerRef.current = marker;
                              }
                              if (typeof finalLng === 'number' && typeof finalLat === 'number' && !isNaN(finalLng) && !isNaN(finalLat)) {
                                try {
                                  mapRef.current.easeTo({ center: [finalLng, finalLat], duration: 400 });
                                } catch (e) {
                                  console.warn("easeTo failed:", e);
                                }
                              }
                            }

                            setMapNotification({
                              type: 'success',
                              title: 'Bâtiment existant identifié !',
                              message: `Votre sélection correspond à un bâtiment déjà répertorié de ${finalArea.toFixed(0)}m² (Taux de recouvrement: ${(bestOverlapRatio * 100).toFixed(0)}%). Nous avons enregistré le polygone parfait du cadastre.`
                            });

                            addApiLog('DRAW_COMPLETE_SNAP_EXISTING', `/map/draw/validate`, null, { 
                              area: finalArea, 
                              snapped: true, 
                              overlapRatio: bestOverlapRatio,
                              buildingId: finalBuildingId,
                              message: "Polygone officiel existant détecté et sauvegardé à la place du dessin manuel pour une précision absolue." 
                            });

                            setIsDrawMode(false);
                            setDrawPoints([]);

                          } else {
                            // --- CAS B : Nouveau bâtiment détecté sans recouvrement suffisant (> 50% non atteint) ---
                            // Déclenche la demande de confirmation géospatiale
                            setShowModelPrompt({
                              geometry: customPolygonGeometry,
                              area: areaVal,
                              lat: centerLat,
                              lng: centerLng
                            });

                            addApiLog('DRAW_COMPLETE_NEW_DETECTED', `/map/draw/validate`, null, {
                              area: areaVal,
                              snapped: false,
                              overlapRatio: bestOverlapRatio,
                              message: "Nouveau bâtiment détecté. Demande de confirmation de modélisation lancée."
                            });

                            setIsDrawMode(false);
                            setDrawPoints([]);
                          }
                        }}
                        disabled={drawPoints.length < 3}
                        className={`flex-1 py-1.5 px-2 rounded-lg text-[10px] font-bold text-center transition-all ${
                          drawPoints.length >= 3 
                            ? 'bg-orange-500 text-slate-950 cursor-pointer hover:bg-orange-400' 
                            : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                        }`}
                      >
                        Valider la Zone
                      </button>
                      <button
                        onClick={() => {
                          if (drawPoints.length === 0) return;
                          setDrawPoints(prev => {
                            const next = prev.slice(0, -1);
                            addApiLog('DRAW_POINT_UNDO', `/map/draw/undo`, null, { total_points: next.length });
                            return next;
                          });
                        }}
                        disabled={drawPoints.length === 0}
                        className={`py-1.5 px-2 rounded-lg text-[10px] font-bold border flex items-center justify-center gap-1 transition-all ${
                          drawPoints.length > 0 
                            ? 'bg-slate-800 hover:bg-slate-750 border-slate-700 text-slate-200 cursor-pointer' 
                            : 'bg-slate-900 border-slate-800 text-slate-600 cursor-not-allowed'
                        }`}
                        title="Annuler le dernier point tracé (Retour en arrière)"
                      >
                        <Undo2 className="w-3.5 h-3.5 shrink-0" />
                        <span>Retour</span>
                      </button>
                      <button
                        onClick={() => {
                          setDrawPoints([]);
                          addApiLog('DRAW_RESET', `/map/draw/reset`, null, { success: true });
                        }}
                        className="py-1.5 px-3 rounded-lg text-[10px] font-bold bg-slate-850 hover:bg-slate-750 border border-slate-800 text-slate-400 cursor-pointer"
                      >
                        Vider
                      </button>
                    </div>
                  </div>
                ) : (
                  <p className="text-[10px] text-slate-300 leading-snug mt-1 italic font-sans">
                    💡 <strong>Clic intelligent :</strong> {currentStyle === 'satellite' ? "Analyse d'image active (Computer Vision). En cliquant sur un toit en vue satellite, l'algorithme calcule en temps réel le détourage exact de la toiture en filtrant le sol et les ombres !" : "Cliquez simplement sur une toiture ou structure 3D de la carte pour en extraire automatiquement le contour vectoriel complet."}
                  </p>
                )}
              </>
            )}
          </div>

          {/* CRÉATION D'ADRESSE : Étape interactive par Clic (Module 1) */}
          <AnimatePresence mode="wait">
            {clickedCoords ? (
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="p-4 bg-slate-800/80 rounded-2xl border border-orange-500/20 shadow-xl shadow-orange-500/5"
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex gap-2">
                    <div className="w-7 h-7 rounded-lg bg-orange-950 border border-orange-500/30 flex items-center justify-center text-orange-400 mt-0.5 shrink-0">
                      <Plus className="w-4 h-4 animate-bounce" />
                    </div>
                    <div>
                      <h3 className="text-sm font-bold text-white font-display">Est-ce bien votre maison ?</h3>
                      <p className="text-[11px] text-slate-400 font-medium">Enregistrement d'un point d'adresse numérique</p>
                    </div>
                  </div>
                  <button onClick={() => setClickedCoords(null)} className="text-slate-400 hover:text-slate-200 shrink-0">
                    <X className="w-4.5 h-4.5" />
                  </button>
                </div>

                <div className="p-3 bg-slate-950/70 rounded-xl mb-3 text-xs font-mono border border-slate-800 space-y-1">
                  <div className="flex justify-between">
                    <span className="text-slate-500">Latitude :</span>
                    <span className="text-slate-300 font-medium">{clickedCoords.latitude.toFixed(6)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Longitude :</span>
                    <span className="text-slate-300 font-medium">{clickedCoords.longitude.toFixed(6)}</span>
                  </div>
                  {clickedCoords.buildingId && (
                    <div className="flex justify-between border-t border-slate-900 pt-1 mt-1 font-sans">
                      <span className="text-slate-500">Type de Toit :</span>
                      <span className="text-emerald-400 font-bold bg-emerald-950/40 px-1 py-0.5 rounded text-[10px]">
                        {String(clickedCoords.buildingId).includes("Zone Dessinée") 
                          ? "Tracé manuel" 
                          : String(clickedCoords.buildingId).includes("Polygone de Carte") || typeof clickedCoords.buildingId === 'number'
                          ? "Bâtiment officiel préservé"
                          : "Généré par IA Vision"}
                      </span>
                    </div>
                  )}
                  {clickedCoords.area !== undefined && (
                    <div className="flex justify-between border-t border-slate-900 pt-1.5 mt-1.5 font-sans items-center">
                      <span className="text-slate-500">Surface Délimitée :</span>
                      <span className="text-orange-400 font-bold bg-orange-950/40 px-2 py-0.5 rounded text-[10px] border border-orange-500/20 select-all">
                        {clickedCoords.area.toLocaleString()} m²
                      </span>
                    </div>
                  )}
                  <div className="flex justify-between border-t border-slate-900 pt-1.5 mt-1.5 font-sans items-center">
                    <span className="text-slate-500">Format de Stockage :</span>
                    <span className="text-emerald-400 font-semibold bg-emerald-950/55 px-2 py-0.5 rounded text-[9px] border border-emerald-500/10">
                      POLYGONE (GeoJSON)
                    </span>
                  </div>
                </div>

                {/* Validation de la vue satellite obligatoire pour éliminer les fausses données */}
                {currentStyle !== 'satellite' ? (
                  <div className="p-3 bg-red-950/50 border border-red-500/30 rounded-xl mb-4 text-[11px] text-red-200 leading-relaxed font-sans space-y-2">
                    <p className="font-bold flex items-center gap-1.5 text-red-400">
                      ⚠️ Vue Satellite Requise Obligatoire
                    </p>
                    <p>
                      Pour enregistrer les contours exacts et éviter les fausses données de toiture, vous devez obligatoirement effectuer l'enregistrement en vue satellite.
                    </p>
                    <button
                      onClick={() => handleStyleChange('satellite')}
                      className="w-full mt-1 bg-orange-500 hover:bg-orange-400 text-slate-950 font-bold font-display py-2 px-3 rounded-lg text-[10px] cursor-pointer transition-all flex items-center justify-center gap-1.5 shadow"
                    >
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>Activer la vue Satellite & HD</span>
                    </button>
                  </div>
                ) : (
                  <div className="p-2.5 bg-emerald-950/40 border border-emerald-500/20 rounded-xl mb-4 text-[10.5px] text-slate-300 leading-snug font-sans space-y-1.5">
                    <p className="font-bold text-emerald-400 flex items-center gap-1">
                      <span>✓</span> Sécurité d'Addressage Active en mode Satellite
                    </p>
                    {String(clickedCoords.buildingId).includes("Zone Dessinée") ? (
                      <p>Tracé libre manuel effectué. Les limites personnalisées de votre toiture vont être enregistrées.</p>
                    ) : String(clickedCoords.buildingId).includes("Polygone de Carte") || typeof clickedCoords.buildingId === 'number' ? (
                      <p className="text-orange-300 text-[10px] leading-tight">
                        <strong>Polygone officiel détecté !</strong> L'algorithme a repéré une forme géométrique pré-existante de la carte. Elle est automatiquement conservée pour une précision certifiée.
                      </p>
                    ) : (
                      <p className="text-sky-300 text-[10px] leading-tight">
                        Aucun polygone enregistré au sol. Notre module de vision par ordinateur IA a automatiquement calculé et généré le contour de votre toiture satellite.
                      </p>
                    )}
                  </div>
                )}

                {/* Formulaire d'information d'adresse */}
                <div className="space-y-3">
                  <div>
                    <label className="block text-[11px] font-mono text-slate-400 mb-1">Nom de l'occupant (Maison / Commerce)</label>
                    <input
                      type="text"
                      placeholder="Ex: Famille Diallo, Boutique Modibo..."
                      value={newOccupantName}
                      onChange={(e) => setNewOccupantName(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-orange-500"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-mono text-slate-400 mb-1">Indications de livraison importantes</label>
                    <textarea
                      placeholder="Ex: Portail noir à 50m après le grand manguier..."
                      value={newDeliveryNotes}
                      onChange={(e) => setNewDeliveryNotes(e.target.value)}
                      rows={2}
                      className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-orange-500 resize-none"
                    />
                  </div>

                  <button
                    onClick={handleCreateUniqueAddress}
                    className={`w-full py-2.5 px-4 rounded-xl text-xs font-bold font-display transition-all flex items-center justify-center gap-1.5 ${
                      currentStyle === 'satellite' 
                        ? 'bg-orange-500 hover:bg-orange-600 active:bg-orange-700 text-slate-950 shadow-lg shadow-orange-500/20 transform hover:-translate-y-0.5 active:translate-y-0 cursor-pointer' 
                        : 'bg-slate-750 text-slate-500 cursor-not-allowed border border-slate-700'
                    }`}
                    disabled={currentStyle !== 'satellite'}
                  >
                    <MapPin className="w-4.5 h-4.5 stroke-[2.5]" />
                    {currentStyle === 'satellite' ? 'Créer mon adresse unique HailandMap' : 'Enregistrement Bloqué (Activer Satellite)'}
                  </button>
                </div>
              </motion.div>
            ) : selectedAddress ? (
              /* DÉTAIL DE L'ADRESSE EN VUE ACTIVE (Module 2) */
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="p-4 bg-slate-800/80 rounded-2xl border border-slate-700 shadow-xl"
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex gap-2">
                    <div className="w-7 h-7 rounded-lg bg-orange-500/10 border border-orange-500/20 flex items-center justify-center text-orange-400 mt-0.5 shrink-0">
                      <MapIcon className="w-4 h-4" />
                    </div>
                    <div>
                      <span className="text-[10px] font-mono text-orange-400 font-bold bg-orange-950/40 px-2 py-0.5 rounded-full border border-orange-500/10">{selectedAddress.id}</span>
                      <h3 className="text-sm font-bold text-white font-display mt-1">{selectedAddress.name}</h3>
                    </div>
                  </div>
                  <button onClick={() => { setSelectedAddress(null); clearRoute(); }} className="text-slate-400 hover:text-slate-200 shrink-0">
                    <X className="w-4.5 h-4.5" />
                  </button>
                </div>

                <p className="text-xs text-slate-300 italic mb-3 font-sans border-l-2 border-orange-500/50 pl-2">
                  "{selectedAddress.notes}"
                </p>

                <div className="p-2.5 bg-slate-950/40 rounded-xl mb-4 text-[11px] font-mono border border-slate-700 flex flex-col gap-1">
                  <div className="flex justify-between">
                    <span className="text-slate-500">Coordonnées :</span>
                    <span className="text-slate-300">{selectedAddress.latitude.toFixed(6)}, {selectedAddress.longitude.toFixed(6)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Créé le :</span>
                    <span className="text-slate-300">{new Date(selectedAddress.createdAt).toLocaleDateString()}</span>
                  </div>
                  {selectedAddress.area !== undefined ? (
                    <div className="flex justify-between border-t border-slate-800 pt-1.5 mt-1.5">
                      <span className="text-slate-500">Surface de zone :</span>
                      <span className="text-orange-400 font-bold bg-orange-950/45 px-2 py-0.5 rounded text-[10px] border border-orange-500/15">
                        {selectedAddress.area.toLocaleString()} m²
                      </span>
                    </div>
                  ) : (
                    <div className="flex justify-between border-t border-slate-800 pt-1.5 mt-1.5">
                      <span className="text-slate-500">Surface estimée :</span>
                      <span className="text-orange-400 font-bold bg-orange-950/45 px-2 py-0.5 rounded text-[10px] border border-orange-500/15">
                        240 m²
                      </span>
                    </div>
                  )}
                  <div className="flex justify-between border-t border-slate-800 pt-1.5 mt-1.5 items-center">
                    <span className="text-slate-500">Format stocké :</span>
                    <span className="text-emerald-400 font-bold bg-emerald-950/45 px-2 py-0.5 rounded text-[9px] border border-emerald-500/10 animate-pulse">
                      POLYGONE GeoJSON
                    </span>
                  </div>
                  <div className="flex justify-between items-center border-t border-slate-800 pt-1.5 mt-1.5">
                    <span className="text-slate-500">Statut :</span>
                    <span className="text-orange-400 font-bold text-[10px] bg-orange-950/50 border border-orange-500/20 px-1.5 py-0.5 rounded flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {selectedAddress.status}
                    </span>
                  </div>
                </div>

                {/* OPTIONS D'ITINÉRAIRE */}
                <div className="space-y-2">
                  {!userLocation ? (
                    <div className="p-3 bg-slate-900 border border-slate-700 rounded-xl flex flex-col gap-2">
                      <p className="text-[11px] text-slate-400">
                        Pour tracer l'itinéraire de livraison, activez le module de localisation GPS réelle.
                      </p>
                      <button
                        onClick={handleGetLocation}
                        className="w-full bg-slate-850 hover:bg-slate-700 border border-slate-700 text-slate-200 py-2 px-3 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-all active:scale-95 cursor-pointer"
                      >
                        <Compass className={`w-4 h-4 text-orange-400 ${isLocating ? 'animate-spin' : ''}`} />
                        Activer ma position GPS réelle
                      </button>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      <div className="flex justify-between items-center text-xs font-mono text-slate-400 bg-slate-950/30 p-2 rounded-lg border border-slate-800/80">
                        <span className="flex items-center gap-1 text-[11px]"><Compass className="w-3.5 h-3.5 text-emerald-400" /> Départ : Position GPS Réelle</span>
                        <button 
                          onClick={() => { setUserLocation(null); }} 
                          className="text-rose-400 hover:text-rose-300 hover:underline text-[10px]"
                        >
                          Désactiver
                        </button>
                      </div>

                      {/* Info d'itinéraire calculé */}
                      {routeLoading ? (
                        <div className="p-4 bg-slate-950 border border-slate-700 rounded-xl flex items-center justify-center gap-2">
                          <RefreshCw className="w-4 h-4 text-orange-400 animate-spin" />
                          <span className="text-xs font-mono text-slate-300">Traçage de la route API Mapbox...</span>
                        </div>
                      ) : routeInfo ? (
                        <div className="p-3 bg-blue-950/40 border border-blue-500/20 rounded-xl space-y-2">
                          <div className="flex items-center gap-2 text-blue-400">
                            <Truck className="w-4.5 h-4.5" />
                            <span className="text-xs font-bold font-display">Calcul complet d'itinéraire de Livraison</span>
                          </div>
                          <div className="grid grid-cols-2 gap-2 text-center">
                            <div className="p-2 bg-slate-950/60 rounded-lg border border-blue-500/10">
                              <span className="text-[10px] text-slate-500 block uppercase font-mono">Distance</span>
                              <span className="text-sm font-bold text-white font-mono">{(routeInfo.distance / 1000).toFixed(2)} km</span>
                            </div>
                            <div className="p-2 bg-slate-950/60 rounded-lg border border-blue-500/10">
                              <span className="text-[10px] text-slate-500 block uppercase font-mono">Temps Estimé</span>
                              <span className="text-sm font-bold text-emerald-400 font-mono">{Math.round(routeInfo.duration / 60)} min</span>
                            </div>
                          </div>
                          <button
                            onClick={clearRoute}
                            className="w-full bg-slate-900 hover:bg-slate-800 border border-slate-700 text-xs py-1.5 px-3 rounded-lg text-slate-400 hover:text-slate-200 transition-colors"
                          >
                            Réinitialiser l'itinéraire
                          </button>
                        </div>
                      ) : (
                        <button
                          onClick={() => calculateRoute(userLocation, selectedAddress)}
                          className="w-full bg-blue-600 hover:bg-blue-500 text-white py-2 px-4 rounded-xl text-xs font-bold font-display flex items-center justify-center gap-1.5 transition-all shadow-lg shadow-blue-600/10"
                        >
                          <Navigation className="w-4 h-4" />
                          Calculer l'itinéraire de livraison
                        </button>
                      )}

                      {routeError && (
                        <div className="p-2 bg-rose-950/40 border border-rose-500/20 rounded-lg text-[11px] text-rose-300 font-mono">
                          ⚠️ {routeError}
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </motion.div>
            ) : (
              /* CONSIGNE PAR DÉFAUT SI AUCUNE ACTION */
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="p-4 bg-slate-800/40 rounded-2xl border border-slate-800 flex flex-col items-center justify-center text-center py-7"
              >
                <div className="w-12 h-12 rounded-2xl bg-slate-900 border border-slate-700 flex items-center justify-center text-slate-400 mb-2.5">
                  <MapPin className="w-6 h-6 text-orange-400 animate-pulse" />
                </div>
                <h3 className="text-xs font-bold text-slate-300 font-display">Sélectionnez ou créez une adresse</h3>
                <p className="text-[11px] text-slate-500 max-w-[250px] mt-1">
                  Cliquez directement sur une toiture ou recherchez une adresse unique pour projeter l'itinéraire de livraison en 3D.
                </p>
              </motion.div>
            )}
          </AnimatePresence>

          {/* LISTE DES ADRESSES ENREGISTRÉES */}
          <div className="space-y-2 pt-1">
            <h3 className="text-xs font-mono font-medium text-slate-400">Adresses Numériques Disponibles ({addresses.length})</h3>
            <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1 no-scrollbar">
              {addresses.map((addr) => {
                const isSelected = selectedAddress?.id === addr.id;
                return (
                  <button
                    key={addr.id}
                    onClick={() => selectAddressFromSearch(addr)}
                    className={`w-full text-left p-2.5 rounded-xl border transition-all flex items-center justify-between text-xs font-sans ${
                      isSelected 
                        ? 'bg-orange-500/10 border-orange-500/40' 
                        : 'bg-slate-950/40 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex flex-col gap-0.5">
                      <span className="font-mono text-[11px] font-bold text-orange-400">{addr.id}</span>
                      <span className="text-slate-300 font-medium whitespace-nowrap overflow-ellipsis overflow-hidden max-w-[190px]">{addr.name}</span>
                    </div>
                    <span className="text-[9px] font-mono text-slate-500 shrink-0 bg-slate-900 px-1.5 py-0.5 rounded border border-slate-800">
                      Conakry
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* BOUTONS FLOTTANTS DE DÉFILEMENT DE LA BARRE GAUCHE (Up & Down arrows requested by user) */}
        <div className="absolute bottom-[160px] right-3 z-30 flex flex-col gap-1 pointer-events-none">
          <button
            onClick={() => scrollSidebar('up')}
            className="w-7 h-7 rounded-full bg-slate-950/90 border border-slate-800 text-slate-400 hover:text-white hover:bg-slate-900 pointer-events-auto flex items-center justify-center shadow-lg transition-all active:scale-90 cursor-pointer"
            title="Défiler vers le haut"
          >
            <ChevronUp className="w-4.5 h-4.5" />
          </button>
          <button
            onClick={() => scrollSidebar('down')}
            className="w-7 h-7 rounded-full bg-slate-950/90 border border-slate-800 text-slate-400 hover:text-white hover:bg-slate-900 pointer-events-auto flex items-center justify-center shadow-lg transition-all active:scale-90 cursor-pointer"
            title="Défiler vers le bas"
          >
            <ChevronDown className="w-4.5 h-4.5" />
          </button>
        </div>

        {/* 2. LOGS API HTTP DE REQUETES DE NOTRE BACKEND (PRO EXPERT FULL-STACK) */}
        <div className="p-4 border-t border-slate-800 bg-slate-950/80 font-mono">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[10px] text-orange-400 flex items-center gap-1.5 font-bold">
              <Code className="w-3.5 h-3.5" />
              CONSOLE API NODE.JS / PG
            </span>
            <span className="text-[9px] text-slate-500 font-semibold uppercase">Logs temps réel</span>
          </div>
          <div className="space-y-1.5 max-h-24 overflow-y-auto no-scrollbar scroll-smooth">
            {apiLogs.length === 0 ? (
              <span className="text-[10px] text-slate-600 italic">En attente d'appels API ou d'événements...</span>
            ) : (
              apiLogs.map((log, idx) => (
                <div key={idx} className="text-[10px] bg-slate-950 border border-slate-800 p-1.5 rounded flex flex-col gap-1">
                  <div className="flex justify-between items-center">
                    <div className="flex items-center gap-1 flex-wrap">
                      <span className={`px-1 py-0.2 rounded text-[8px] font-bold ${
                        log.method === 'POST' ? 'bg-indigo-950 text-indigo-400 border border-indigo-800/30' :
                        log.method === 'GET' ? 'bg-emerald-950 text-emerald-400 border border-emerald-800/30' :
                        log.method === 'EVENT_CLICK' ? 'bg-amber-950 text-amber-400 border border-amber-800/30' :
                        'bg-slate-900 text-slate-400'
                      }`}>
                        {log.method}
                      </span>
                      <span className="text-slate-300">{log.url}</span>
                    </div>
                    <span className="text-slate-600 text-[8px]">{log.timestamp}</span>
                  </div>
                  {log.body && (
                    <pre className="text-[8px] text-slate-400 bg-slate-900/50 p-1 rounded overflow-x-auto whitespace-pre">
                      {JSON.stringify(log.body, null, 2)}
                    </pre>
                  )}
                  {log.response && (
                    <div className="flex gap-1 items-center border-t border-slate-900/40 pt-1 mt-0.5 text-[8px] text-slate-500">
                      <span className="font-bold text-[8px] text-emerald-500">RES:</span>
                      <span className="truncate">{JSON.stringify(log.response)}</span>
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        </div>

      </div>

      {/* 3. CAPTURE DE LA CARTE MAPBOX EN PLEIN ÉCRAN */}
      <div className="flex-1 relative h-full w-full">
        
        {/* LE CONTENEUR DE LA CARTE */}
        <div ref={mapContainerRef} className="absolute inset-0 w-full h-full" id="mapbox-viewport" />

        {/* BOUTON FLOTTANT DE MENU POUR RE-OUVRIR LE PANNEAU LATÉRAL */}
        {!isSidebarOpen && (
          <button
            onClick={() => setIsSidebarOpen(true)}
            className="absolute top-4 left-4 z-20 p-3 bg-slate-900 border border-slate-700 text-orange-400 rounded-2xl shadow-2xl transition-all cursor-pointer active:scale-95 flex items-center justify-center gap-2 hover:bg-slate-850 group ring-1 ring-white/10"
            title="Ouvrir le panneau"
          >
            <Menu className="w-5 h-5 text-orange-400 group-hover:rotate-90 transition-transform duration-300" />
            <span className="text-xs font-bold text-white font-display uppercase tracking-wide px-1">Menu</span>
          </button>
        )}

        {/* ENCART DE NOTIFICATION DES OPÉRATIONS DE DÉTOURAGE ET DE VALIDATION ALGORITHMIQUE */}
        <AnimatePresence>
          {mapNotification && (
            <motion.div
              initial={{ opacity: 0, y: -20, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -10, scale: 0.95 }}
              transition={{ duration: 0.3, ease: "easeOut" }}
              className="absolute top-4 right-4 z-50 max-w-sm w-[90vw] bg-slate-900/95 border border-slate-700/80 rounded-2xl p-4 shadow-2xl backdrop-blur-md ring-1 ring-white/10"
            >
              <div className="flex gap-3">
                <div className={`p-2 rounded-lg shrink-0 flex items-center justify-center ${
                  mapNotification.type === 'success' ? 'bg-emerald-950/85 text-emerald-400 border border-emerald-500/20' :
                  mapNotification.type === 'warning' ? 'bg-amber-950/85 text-amber-500 border border-amber-500/20' :
                  'bg-blue-950/85 text-blue-400 border border-blue-500/20'
                }`}>
                  {mapNotification.type === 'success' ? <CheckCircle className="w-5 h-5 flex-shrink-0" /> :
                   mapNotification.type === 'warning' ? <AlertTriangle className="w-5 h-5 flex-shrink-0" /> :
                   <Info className="w-5 h-5 flex-shrink-0" />}
                </div>
                
                <div className="flex-1 space-y-1">
                  <div className="flex items-start justify-between">
                    <h4 className="text-xs font-bold text-white font-display leading-tight">
                      {mapNotification.title}
                    </h4>
                    <button 
                      onClick={() => setMapNotification(null)}
                      className="text-slate-400 hover:text-white text-xs p-0.5 hover:bg-slate-800 rounded transition-all cursor-pointer"
                    >
                      ✕
                    </button>
                  </div>
                  <p className="text-[11px] text-slate-300 leading-snug font-sans text-left">
                    {mapNotification.message}
                  </p>
                </div>
              </div>
              
              {/* Petite barre d'auto-destruction visuelle animée */}
              <div className="mt-3 h-0.5 w-full bg-slate-800 rounded-full overflow-hidden">
                <motion.div 
                  initial={{ width: "100%" }}
                  animate={{ width: "0%" }}
                  transition={{ duration: 8, ease: "linear" }}
                  className={`h-full ${
                    mapNotification.type === 'success' ? 'bg-emerald-500' :
                    mapNotification.type === 'warning' ? 'bg-amber-500' :
                    'bg-blue-500'
                  }`}
                />
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* PROMPT DE CONFIRMATION DE MODÉLISATION 3D (CAS B) */}
        <AnimatePresence>
          {showModelPrompt && (
            <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="w-full max-w-sm bg-slate-900 border border-slate-700/80 rounded-2xl p-5 shadow-2xl space-y-4 text-left"
              >
                <div className="flex items-center gap-3">
                  <div className="p-2.5 bg-orange-950/80 text-orange-400 border border-orange-500/20 rounded-xl">
                    <Sparkles className="w-5 h-5 animate-pulse" />
                  </div>
                  <div>
                    <h3 className="text-xs font-extrabold text-white font-display tracking-tight uppercase">🆕 Nouveau Bâtiment</h3>
                    <p className="text-[10px] text-slate-400 font-medium font-sans">Cadastre HailandMap Guinée</p>
                  </div>
                </div>

                <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 space-y-2 font-sans">
                  <p className="text-[11px] text-slate-300 leading-relaxed">
                    Aucun bâtiment 3D officiel pré-existant ne correspond à cette surface dans notre base géométrique.
                  </p>
                  <div className="flex justify-between items-center bg-slate-900/50 p-2 rounded border border-slate-850 font-mono text-[11px]">
                    <span className="text-slate-500">Surface estimée :</span>
                    <span className="text-orange-400 font-bold">{showModelPrompt.area.toFixed(1)} m²</span>
                  </div>
                  <p className="text-[11px] text-slate-400 italic">
                    Souhaitez-vous valider votre tracé pour modéliser cette nouvelle maison en 3D ?
                  </p>
                </div>

                <div className="flex gap-2">
                  <button
                    onClick={() => setShowModelPrompt(null)}
                    className="flex-1 py-2 px-3 rounded-xl border border-slate-750 text-slate-300 hover:text-white bg-slate-800/40 hover:bg-slate-800 text-[11px] font-bold transition-all cursor-pointer text-center"
                  >
                    Annuler
                  </button>
                  <button
                    onClick={() => {
                      setClickedCoords({
                        latitude: showModelPrompt.lat,
                        longitude: showModelPrompt.lng,
                        buildingId: "Nouveau Bâtiment Modélisé en 3D",
                        geometry: showModelPrompt.geometry,
                        area: showModelPrompt.area
                      });

                      // Mettre à jour le polygone orange sur la carte
                      if (mapRef.current) {
                        const selSource = mapRef.current.getSource('selected-building') as mapboxgl.GeoJSONSource;
                        if (selSource) {
                          selSource.setData({
                            type: 'Feature',
                            properties: {},
                            geometry: showModelPrompt.geometry
                          });
                        }
                        
                        // Déplacer/Créer le marqueur maison orange
                        if (typeof showModelPrompt.lng === 'number' && typeof showModelPrompt.lat === 'number' && !isNaN(showModelPrompt.lng) && !isNaN(showModelPrompt.lat)) {
                          if (markerRef.current) {
                            markerRef.current.setLngLat([showModelPrompt.lng, showModelPrompt.lat]);
                          } else {
                            const el = document.createElement('div');
                            el.className = 'custom-house-marker';
                            el.innerHTML = `
                              <div class="flex items-center justify-center w-10 h-10 bg-orange-500 rounded-full border-2 border-slate-900 shadow-xl shadow-orange-500/30 transform transition-transform duration-200 hover:scale-110 cursor-pointer">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" class="w-5 h-5 text-slate-950">
                                  <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
                                  <polyline points="9 22 9 12 15 12 15 22"></polyline>
                                </svg>
                              </div>
                              <div class="w-2.5 h-2.5 bg-orange-500 border border-slate-900 rounded-full mx-auto -mt-1 shadow-md animate-ping"></div>
                            `;
                            const marker = new mapboxgl.Marker({ element: el })
                              .setLngLat([showModelPrompt.lng, showModelPrompt.lat])
                              .addTo(mapRef.current);
                            markerRef.current = marker;
                          }
                        }
                      }

                      setMapNotification({
                        type: 'success',
                        title: 'Modélisation Initiée !',
                        message: 'Les nouveaux contours personnalisés ont été validés. Veuillez maintenant compléter le nom de l\'occupant.'
                      });

                      setShowModelPrompt(null);
                    }}
                    className="flex-1 py-2 px-3 rounded-xl bg-orange-500 hover:bg-orange-600 text-slate-950 text-[11px] font-bold transition-all shadow-lg shadow-orange-500/15 cursor-pointer text-center"
                  >
                    Oui, Modéliser 3D
                  </button>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>

        {/* COMPOSANT DE SELECTION DU JETON MAPBOX EN CAS D'ÉDITIONS */}
        <div className="absolute top-4 left-4 z-20 flex flex-col gap-2 max-w-[85vw] sm:max-w-md">
          <div className="flex flex-col sm:flex-row gap-2">
            {/* SÉLECTEUR DE STYLE CARTE */}
            <div className="flex bg-slate-950/90 border border-slate-800 backdrop-blur-md rounded-xl p-1 shadow-lg ring-1 ring-slate-800">
              {styles.map(style => (
                <button
                  key={style.id}
                  onClick={() => handleStyleChange(style.id)}
                  className={`px-2.5 py-1.5 rounded-lg text-[10px] font-bold font-display transition-all ${
                    currentStyle === style.id 
                      ? 'bg-orange-500 text-slate-950 shadow' 
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {style.name}
                </button>
              ))}
            </div>

            {/* RAPIDE CONFIRMATION DU COMPTE JETON */}
            <div className="hidden sm:flex bg-slate-955/90 border border-slate-800 backdrop-blur-md rounded-xl p-1.5 px-3 items-center gap-1.5 text-[10px] text-slate-400 font-mono shadow-lg ring-1 ring-slate-800">
              <Layers className="w-3.5 h-3.5 text-orange-400" />
              <span>Mapbox Style d'Hailand</span>
            </div>
          </div>

          {/* INDICATEUR D'AMÉLIORATION SATELLITE SUPER-RÉSOLUTION IA */}
          {currentStyle === 'satellite' && (
            <div className="bg-slate-950/95 border border-orange-500/40 backdrop-blur-md rounded-2xl p-3 shadow-2xl ring-1 ring-orange-500/10 flex flex-col gap-1.5 animate-in fade-in slide-in-from-top-2 duration-300">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="relative flex h-2 w-2">
                    {isHdEnhanceForce && (
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-orange-400 opacity-75"></span>
                    )}
                    <span className={`relative inline-flex rounded-full h-2 w-2 ${isHdEnhanceForce ? 'bg-orange-500' : 'bg-slate-600'}`}></span>
                  </span>
                  <span className="text-[10px] font-bold font-display text-orange-400 uppercase tracking-wider">
                    Super-Résolution IA & Dé-Floutage
                  </span>
                </div>
                <span className={`text-[9px] px-1.5 py-0.5 rounded font-mono font-bold ${isHdEnhanceForce ? 'bg-orange-950 text-orange-300 border border-orange-500/20' : 'bg-slate-800 text-slate-400'}`}>
                  {isHdEnhanceForce ? 'ACTIF (MODE HD)' : 'DÉSACTIVÉ'}
                </span>
              </div>

              {/* BOUTON D'ACTION DE DÉ-FLOUTAGE INTERACTIF */}
              <button
                onClick={() => {
                  setIsHdEnhanceForce(!isHdEnhanceForce);
                  addApiLog('TOGGLE_CV_HD', `/map/satellite/hd-mode`, null, { active: !isHdEnhanceForce });
                }}
                className={`mt-1 w-full py-1.5 px-3 rounded-xl text-[10px] font-bold font-display transition-all duration-200 flex items-center justify-center gap-1.5 cursor-pointer active:scale-95 ${
                  isHdEnhanceForce 
                    ? 'bg-orange-500 text-slate-950 hover:bg-orange-400 font-bold shadow-lg shadow-orange-500/20' 
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700 hover:text-white border border-slate-700'
                }`}
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>{isHdEnhanceForce ? "Désactiver la Super-Netteté IA" : "Activer la Super-Netteté (Dé-flouter)"}</span>
              </button>

              <div className="flex justify-between items-center text-[9px] text-slate-400 font-mono mt-0.5 pt-1.5 border-t border-slate-800">
                <span>Zoom actuel : <strong className="text-white">{zoomLevel.toFixed(1)}</strong> / 22.0</span>
                <span className="text-[8px] text-slate-500">{isHdEnhanceForce ? "Convolution active" : "Brut"}</span>
              </div>
            </div>
          )}
        </div>

        {/* CONTROLEURS SUPERPOSÉS À DROITE */}
        <div className="absolute bottom-6 right-4 z-20 flex flex-col gap-2">
          
          {/* BOUTON INTUITIF GPS REEL */}
          <button
            onClick={handleGetLocation}
            disabled={isLocating}
            className={`w-12 h-12 rounded-2xl active:scale-95 border backdrop-blur-md shadow-xl flex items-center justify-center transition-all cursor-pointer group ${
              userLocation 
                ? 'bg-emerald-600 hover:bg-emerald-500 border-emerald-400 text-white shadow-emerald-600/20' 
                : 'bg-slate-900 hover:bg-slate-850 border-slate-700 text-slate-200 hover:text-orange-400'
            }`}
            title={userLocation ? "GPS Actif (Désactiver en cliquant sur le panel gauche)" : "Ma Position GPS Réelle"}
          >
            <Compass className={`w-5 h-5 ${isLocating ? 'animate-spin' : 'group-hover:rotate-12 transition-transform'}`} />
          </button>
        </div>

        {/* RUSTINE DE BIENVENUE & CONSEIL GPS */}
        <div className="absolute bottom-6 left-4 z-20 pointer-events-none max-w-sm hidden lg:block">
          <div className="bg-slate-950/90 border border-slate-800 backdrop-blur-md p-3 rounded-2xl shadow-2xl pointer-events-auto flex items-start gap-2.5">
            <div className="w-7 h-7 rounded-lg bg-orange-500/15 flex items-center justify-center text-orange-400 mt-0.5 pointer-events-none shrink-0 border border-orange-500/15">
              <Info className="w-4 h-4" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-slate-100 font-display">Conseil d'utilisation</h4>
              <p className="text-[10px] text-slate-400 mt-0.5 leading-relaxed font-sans">
                Activez votre départ de livraison en utilisant votre <span className="text-emerald-400 font-bold">GPS Réel</span> (bouton vert/boussole) puis cliquez sur un bâtiment sur la carte pour tracer l'itinéraire instantanément.
              </p>
            </div>
          </div>
        </div>

      </div>

    </div>
  );
}er border-orange-500/15">
              <Info className="w-4 h-4" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-slate-100 font-display">Conseil d'utilisation</h4>
              <p className="text-[10px] text-slate-400 mt-0.5 leading-relaxed font-sans">
                Activez le point de départ en simulant le GPS (<span className="text-blue-400 font-bold">GPX</span>) puis cliquez sur un bâtiment sur la carte. Validez l'adresse pour que l'itinéraire s'affiche instantanément.
              </p>
            </div>
          </div>
        </div>

      </div>

    </div>
  );
}
